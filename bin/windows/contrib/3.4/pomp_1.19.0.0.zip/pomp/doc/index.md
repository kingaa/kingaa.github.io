---
title: "*pomp* user guides and tutorials"
---

Visit the [**pomp** website](https://kingaa.github.io/pomp/docs.html) for the pomp paper, tutorials, examples, and other documentation.

[**pomp** FAQ](https://kingaa.github.io/pomp/FAQ.html)

[Package NEWS](https://kingaa.github.io/pomp/NEWS.html)

[Report issues with the package](https://github.com/kingaa/pomp/issues)

[Back to the **pomp** package index](../html/00Index.html)
