---
title: "phylopomp"
subtitle: "user guides, vignettes, and tutorials"
---

<style>
html {
    overflow-y:scroll;
}

body {
    color: #000000;
    background: #ffffff;
    font-family: "DejaVu Sans", "Arial Sans", Arial, sans;
    max-width: 1000px;
    margin-top: 20px;
    margin-bottom: 30px;
    margin-left: 30px;
    margin-right: 30px;
}

.emph {
    color: #ff0000;
    font-weight: bold;
}

.firstcharacter { 
    float: left; 
    color: #3333ff; 
    font-size: 40px; 
    line-height: 30px;
    vertical-align: top;
    padding-right: 5px;
}

code {
    font-family: monospace;
    font-size: 1.125em;
}

h1, h2, h3, h4 {
    font-family: "DejaVu Sans", "Arial Sans", Arial, sans;
    font-weight: bold;
    font-variant: normal;
}
h1 {
    font-size: 1.25em;
}
h2 {
    font-size: 1.125em;
}
h3 {
    font-size: 1.0625em;
}
h4 {
    font-size: 1.0em;
}
p, ul, ol {
    text-align: left;
}
td {
    vertical-align: top;
}
a:link, a:visited {
    color: #0000ff;
    text-decoration: none;
}
a:hover, a:active {
    color: #ff3333;
    text-decoration: none;
}
thead {
    display: table-header-group;
}
dl, ul, ol, dd {
    page-break-before: avoid;
}
dt, dd, tr, h1, h2, h3, h4, li, p {
    page-break-inside: avoid;
}
dt, h1, h2, h3, h4 {
    page-break-after: avoid;
}
dt, dd {
    text-align: left;
}
dt {
    font-weight: bold;
}
.toc {
    list-style: none;
}
</style>

- [**phylopomp** manual](https://kingaa.github.io/manuals/phylopomp/)
- [Vignettes](https://kingaa.github.io/manuals/phylopomp/vignettes/)
- [Source code](https://github.com/kingaa/phylopomp/)
- [Package NEWS](https://kingaa.github.io/manuals/phylopomp/html/NEWS.html)
- <a href="#" onclick="goBack()">Back to the previous page</a>

<script>
function goBack() {
window.history.back();
}
</script>
