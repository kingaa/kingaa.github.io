##' circumstance package
##'
##' The \pkg{circumstance} package
##'
##' @name circumstance-package
##' @import methods
##'
NULL
