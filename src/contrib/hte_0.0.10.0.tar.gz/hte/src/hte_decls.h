/* src/filter.c */
extern SEXP Bernoulli_Filter_Wrapper(SEXP Alpha, SEXP Beta, SEXP P0, SEXP Isol_Factor, SEXP Patno, SEXP Result, SEXP Isol, SEXP Rowid, SEXP Loc, SEXP Dim, SEXP Lambda, SEXP Gamma, SEXP Unit, SEXP Time);
extern void Bernoulli_Filter(const double *Alpha, const double *Beta, const double *p0, const double *isol_fact, const int *patno, const int *result, const int *isol, const int *rowid, const int *loc, const int *dim, const double *Lambda, const double *Gamma, const double *Time, int *Occ, double *Prev_i, double *Prev_u, double *Loglik);
extern void BFilter(const double *Alpha, const double *Beta, const double *p0, const double *isol_fact, const int *result, const int *isol, const int *loc, const double *time, const int *dim, const double *lambda, const double *gamma, double *logLik);
/* src/init.c */
extern void R_init_hte(DllInfo *info);
