##' Hospital transmission estimation
##'
##' The \pkg{hte} package ...
##'
##' @name hte-package
##' @aliases hte,package
##' @rdname package
##' @docType package
##' @author Aaron A. King
##' @useDynLib hte, .registration = TRUE, .fixes="C_"
##' @import methods
##' 
NULL

.onAttach <- function (...) {
  options(dplyr.summarise.inform=FALSE)
}

pStop <- function (..., which = -1L) {
  which <- as.integer(which)
  if (length(which)>0L) {
    fn <- sys.call(which[1L])
    stop("in ",sQuote(fn[[1L]]),": ",...,call.=FALSE)
  } else {
    stop(...,call.=FALSE)
  }
}

pWarn <- function (..., which = -1L) {
  which <- as.integer(which)
  if (length(which)>0L) {
    fn <- sys.call(which[1L])
    warning("in ",sQuote(fn[[1L]]),": ",...,call.=FALSE)
  } else {
    warning(...,call.=FALSE)
  }
}

pMess <- function (..., which = -1L) {
  which <- as.integer(which)
  if (length(which)>0L) {
    fn <- sys.call(which[1L])
    message("NOTE: in ",sQuote(fn[[1L]]),": ",...)
  } else {
    message("NOTE: ",...)
  }
}
