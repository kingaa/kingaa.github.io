#include "hte_internal.h"
#include <R_ext/Rdynload.h>

static R_NativePrimitiveArgType BFilter_t[] = {
  REALSXP, REALSXP, REALSXP, REALSXP, INTSXP, INTSXP,
  INTSXP, REALSXP, INTSXP, REALSXP, REALSXP, REALSXP
};

static const R_CMethodDef cMethods[] = {
  {"BFilter", (DL_FUNC) &BFilter, 12, BFilter_t},
  {NULL, NULL, 0, NULL}
};

static const R_CallMethodDef callMethods[] = {
  {"Bernoulli_Filter", (DL_FUNC) &Bernoulli_Filter_Wrapper, 14},
  {NULL, NULL, 0}
};

void R_init_hte (DllInfo *info) {
  // Register routines
  R_registerRoutines(info,cMethods,callMethods,NULL,NULL);
  R_useDynamicSymbols(info,FALSE);
  R_forceSymbols(info,TRUE);
}
