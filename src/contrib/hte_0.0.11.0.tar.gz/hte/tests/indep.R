library(tidyverse)
library(lubridate)
library(pomp)
library(hte)

set.seed(299012132)

fake_data |>
  arrange(patient,time) -> dat

indep_homog_objfun(
  params=c(
    lambda=0.1,gamma=0.01,p0=0.1,
    isol_factor=0.2,alpha=0.02,beta=0.1
  ),
  est=c("lambda","gamma"),
  data=dat
) -> f

optim(
  par=log(c(0.15,0.015)),
  fn=f,
  method="BFGS",
  control=list(reltol=1e-4)
) -> out
-f(out$par) -> ll
ll
coef(f)

indep_homog_filter(params=coef(f),data=dat) -> ff
stopifnot(
  all.equal(sum(ff$logLik),ll),
  ff |> filter(logLik!=0,is.na(patient)) |> nrow()==0
)

theta <- coef(f)
indep_unit_spec_objfun(
  params=c(
    lambda=setNames(rep.int(theta["lambda"],6),unique(dat$unit)),
    gamma.out=unname(theta["gamma"]),
    theta[c("p0","gamma","alpha","beta","isol_factor")]
  ),
  est=c("lambda.out","gamma.out"),
  data=dat
) -> h

optim(
  par=log(coef(h)[c("lambda.out","gamma.out")]),
  fn=h,
  method="BFGS",
  control=list(reltol=1e-4)
) -> out
-h(out$par) -> ll
ll
coef(h)

indep_unit_spec_filter(params=coef(h),data=dat) -> hh
stopifnot(all.equal(sum(hh$logLik),ll))

try(
  indep_homog_objfun(
    params=c(
      harry=0.1,gamma=0.01,p0=0.1,
      isol_factor=0.2,alpha=0.02,beta=0.1
    ),
    est=c("lambda","gamma"),
    data=dat
  )
)

try(
  indep_homog_objfun(
    params=c(
      lambda=0.1,gamma=0.01,p0=0.1,
      isol_factor=0.2,alpha=0.02,beta=0.1
    ),
    est=c("bob","gamma"),
    data=dat
  )
)

try(
  indep_homog_objfun(
    params=c(
      lambda=0.1,gamma=0.01,p0=0.1,
      isol_factor=0.2,alpha=0.02,beta=0.1
    ),
    est=c("bob","gamma"),
    data=dat
  )
)
