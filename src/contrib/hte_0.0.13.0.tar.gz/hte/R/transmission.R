##' Transmission model
##'
##' Model under which the force of infection in each unit is
##' proportional to the prevalence of infection in that unit.
##'
##' The basic transmission model assumes that the force of infection
##' on an unisolated patient is
##' \deqn{\lambda=b(P_u+aP_i),}{lambda=b*(Pu+a*Pi),}
##' where \eqn{P_u}{Pu}, \eqn{P_i}{Pi} are the prevalences among unisolated
##' and isolated patients, respectively.
##' On an isolated patient, this force of infection is reduced by the factor
##' \code{isol_factor}.
##'
##' Parameters in the model include:
##' \describe{
##'   \item{b}{transmission rate. In the homogeneous model, this is constant across units in the hospital; in the unit-specific model, there is one value of \code{b} for each unit.}
##'   \item{lambda.out}{force of infection outside the hospital}
##'   \item{gamma}{recovery rate}
##'   \item{alpha,beta}{false positive and negative probabilities}
##'   \item{p0}{probability of infection on admission}
##'   \item{a}{multiplicative effect of contact isolation on transmissibility}
##'   \item{isol_factor}{multiplicative effect of contact isolation on susceptibility}
##' }
##' @name transmission
##' @rdname transmission
##' @family transmission model
##' @family stateful objective functions
##' @include bfilter.R stobfun.R
##' @example examples/transmiss.R
NULL

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @param tol positive scalar; convergence tolerance (mean difference).
##' @param maxit scalar integer; maximum number of fixed-point iterations.
##' If \code{tol} is not achieved in \code{maxit} or fewer iterations, an error is generated.
##' @details \code{trans_homog_filter} runs a fixed-point Bernoulli filter
##' for the transmission model with global b and gamma.
##' @export
trans_homog_filter <- function (
  params, data,
  tol = 1e-4, maxit = 10
) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  nunit <- length(dat$unitnames)
  filterfun(
    embedding(
      a="a",
      b=rep.int("b",nunit-1L),
      gamma=rep.int("gamma",nunit),
      lambda=c("lambda.out",rep.int("gamma",nunit-1L)),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    tol=tol,
    maxit=maxit,
    filtfun=transmiss_fixed_point
  ) -> f
  f(params)
}

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @param tol positive scalar; convergence tolerance (mean difference).
##' @param maxit scalar integer; maximum number of fixed-point iterations.
##' If \code{tol} is not achieved in \code{maxit} or fewer iterations, an error is generated.
##' @details \code{trans_homog_objfun} is a stateful objective
##' function for the transmission model with global b and gamma.
##' @export
trans_homog_objfun <- function (
  params, data, est = character(0),
  tol = 1e-4, maxit = 10
) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  nunit <- length(dat$unitnames)
  stobfun(
    embedding(
      a="a",
      b=rep.int("b",nunit-1L),
      gamma=rep.int("gamma",nunit),
      lambda=c("lambda.out",rep.int("gamma",nunit-1L)),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("a","b","gamma","isol_factor","lambda.out"),
    logit=c("alpha","beta","p0"),
    tol=tol,
    maxit=maxit,
    objfun=nll_fixed_point
  )
}

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @param tol positive scalar; convergence tolerance (mean difference).
##' @param maxit scalar integer; maximum number of fixed-point iterations.
##' If \code{tol} is not achieved in \code{maxit} or fewer iterations, an error is generated.
##' @details \code{trans_unit_spec_filter} runs a fixed-point Bernoulli filter
##' for the transmission model with unit-specific b.
##' @export
trans_unit_spec_filter <- function (
  params, data,
  tol = 1e-4, maxit = 10
) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  units <- dat$unitnames
  filterfun(
    embedding(
      a="a",
      b=paste("b",units[-1L],sep="."),
      lambda=c("lambda.out",rep.int("gamma",length(units)-1L)),
      gamma=rep.int("gamma",length(units)),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    tol=tol,
    maxit=maxit,
    filtfun=transmiss_fixed_point
  ) -> f
  f(params)
}

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @details \code{trans_unit_spec_objfun} is a stateful objective function
##' for the transmission model with unit-specific transmission rates,
##' an out-of-hospital force of infection parameter,
##' and recovery rates that can be different inside and outside of hospital.
##' @export
trans_unit_spec_objfun <- function (
  params, data, est = character(0),
  tol = 1e-4, maxit = 10
  ) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  units <- dat$unitnames
  bs <- paste("b",units[-1L],sep=".")
  stobfun(
    embedding(
      a="a",
      b=bs,
      lambda=c("lambda.out",rep.int("gamma",length(units)-1L)),
      gamma=rep.int("gamma",length(units)),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("a",bs,"gamma","lambda.out","isol_factor"),
    logit=c("alpha","beta","p0"),
    tol=tol,
    maxit=maxit,
    objfun=nll_fixed_point
  )
}

##' @importFrom dplyr coalesce
transmiss_fixed_point <- function (
  theta, data,
  tol = 1e-4, maxit = 10
) {
  nunit <- length(data$unitnames)
  lambda <- tryCatch(
    extend_vec(theta$lambda,nunit,data$dim[4L]),
    error = function (e) pStop("lambda: ",conditionMessage(e),which=NULL)
  )
  gamma <- tryCatch(
    extend_vec(theta$gamma,nunit,data$dim[4L]),
    error = function (e) pStop("gamma: ",conditionMessage(e),which=NULL)
  )
  B <- c(0,theta$b)
  if (length(B)!=nunit) pStop("bad b parameter!")
  data |>
    Bernoulli_filter_internal(
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    ) -> ff
  lambda <- coalesce(
    B*(ff$prev_u + theta$a*ff$prev_i),
    lambda
  )
  gamma <- ff$gamma
  i <- 0L
  dist <- Inf
  while (dist > tol && i < maxit) {
    data |>
      Bernoulli_filter_internal(
        lambda=lambda,
        gamma=gamma,
        p0=theta$p0,
        alpha=theta$alpha,
        beta=theta$beta,
        isol_factor=theta$isol_factor
      ) -> ff
    new_lambda <- B*(ff$prev_u + theta$a*ff$prev_i)
    dist <- mean(abs(new_lambda-lambda),na.rm=TRUE)
    lambda <- coalesce(new_lambda,lambda)
    i <- i+1L
  }
  if (dist > tol)
    pWarn("maximum number of iterations reached!")
  ff
}

nll_fixed_point <- function (
  theta, data,
  tol = 1e-4, maxit = 10
) {
  ff <- transmiss_fixed_point(theta=theta,data=data,tol=tol,maxit=maxit)
  -sum(ff$logLik)
}
