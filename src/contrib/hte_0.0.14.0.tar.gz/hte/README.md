##  hte: hospital transmission estimation

- [Package manual](https://kingaa.github.io/manuals/hte/)

---------------------

- Two model types at present are included:
  - In the *independent infection model*, the force of infection $\lambda$ in each unit at each time is given.
	Conditional on this, each patient's infection is independent.
	To compute the likelihood of the observed test results given, one runs a "Bernoulli filter".
	- The `Bfilter` and `Bernoulli filter` functions perform this computation.
	- The stateful objective functions `indep_homog_objfun`, `indep_unit_spec_objfun` can be optimized to estimate the parameters of this model.
  - In the *transmission model*, the force of infection is assumed proportional to the prevalence.
	In particular, it assumes that $\lambda = b (P_u + a P_i)$, where $P_i,P_u$ are the prevalences of infection among isolated and un-isolated patients, respectively, and the coefficients $b,ab$ are transmission rates.
	If this equation holds, one can compute the likelihood of the data under this model using the Bernoulli filter as in the case of the independent infection model.
	The algorithms underlying the objective functions `trans_homog_objfun` and `trans_unit_spec_objfun` employ a fixed-point iteration procedure to achieve the equation linking $\lambda$ to $P_i,P_u$.
- There is also support for generating fake data sets.
  These include patient movements through various units (including multiple discharges and re-admissions), entry and exit from contact isolation, testing, and infection.
  At the moment, only the independent infection model is implemented for these simulations.
  See the function `simuldat` and the pre-generated dataset `fake_data`.

---------------------

### Building, checking, installing

At a shell prompt:
- `make` causes the documentation to be rebuilt
- `make dist` causes a source tarball for the **R** package to be built.
  This can be installed in the usual way:
  - `R CMD INSTALL <package>.tar.gz` at a shell prompt
  - `install.packages("<package>.tar.gz")` in an **R** session
- `make check` causes the package checking system to run
- `make rsession` installs the package in a temporary location and starts an interactive session.
  This is useful for debugging purposes.
- `make clean` and `make fresh` clean up afterward.

To install hte on Armis2 cluster:
- Switch to hte directory
- module load R/4.2.0 
- Make sure devtools is installed!
- `make`
- `make dist`
- `R CMD INSTALL <package>.tar.gz`

See the file `rules.mk` for other `make` targets.

One can also use the package development tools in **RStudio**.

----------------------

### Parallel computations

I recommend using the [**doFuture**](https://dofuture.futureverse.org/) backend for `foreach`.

----------------------

### Suggested workflow

1. Estimate homogenous independent model
2. Use estimates from homogenous independent model as starting points for estimating unit-specific independent model.
3. Use parameter estimates and estimated prevalences from unit-specific independent model to find starting guesses for unit-specific transmission rates.
4. Use the latter to estimate the unit-specific transmission model.

- An equally plausible route is homogenous independent to homogeneous transmission to unit-specific transmission.

- With a pathway that yields one set of estimates, one can explore running the same pathway from different starting points.
- One can also spread guesses out at intermediate points along the pathway.

-------------------------

## A true EM algorithm

Is the following a correct EM algorithm?

1. For given parameters, generate many draws from the smoothing distribution.
1. Construct a "full-likelihood" function: as a function of the model parameters, average the likelihood across the smoothing draws.
1. Maximize the latter function across parameters.
1. Repeat to convergence.

To operationalize this, we need two things:  
1. A Monte Carlo filter that randomly collapses the individual-patient $p(t)$ to 0-1 infection trajectories.
   A single run of this filter will yield a draw from the smoothing distribution.
1. A filter that computes the likelihood of the data for each such trajectory.
   This is a minor variation on the existing Bernoulli filter.

-------------------------
