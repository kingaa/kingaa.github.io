##' @title twostate
##' @description Two-state Markov process with on and off rates
##' @name twostate
##' @rdname twostate
##' @include package.R
##' @param on,off on and off rates
##' @param t0,tf initial and final times
##' @importFrom utils tail
##' @importFrom stats rpois rexp
##' @export
twostate <- function (on, off, tf, t0 = 0) {
  t <- t0
  tout <- numeric(0L)
  while (t < tf) {
    n <- 2*(1+rpois(n=1,lambda=2*on*off/(on+off)*(tf-t0)))
    ts <- t+cumsum(rexp(n=n,rate=c(on,off)))
    t <- tail(ts,1)
    tout <- c(tout,ts)
  }
  tibble(
    time=tout[tout<tf],
    state=rep_len(c(1L,-1L),length(time))
  )
}
