##' Agent-based colonization/decolonization model
##'
##' Given patient movement data, simulated transmission dynamics
##' and screening.
##'
##' @name abm
##' @rdname abm
##' @family simulated data
##' @family transmission model
##' @include package.R fake_data.R
##' @param data a data frame containing patient movement and testing information.
##' It should have at least the following columns:
##' \describe{
##'   \item{patient}{a unique identifier for each patient}
##'   \item{unit}{a unique identifier for each unit}
##'   \item{time}{a number representing time}
##'   \item{event}{a character vector specifying the kind of event:
##'     admission, discharge, transfer, or test.
##'   }
##' }
##' @param b transmission rate
##' @param lambda0 background colonization rate
##' @param gamma decolonization rate
##' @param p0 probability of colonization on admission
##' @param alpha,beta false positive and negative testing error rates
##' @param adm_eff numeric; efficiency of testing on admission
##' @param status_changes logical; should true times of colonization or decolonization events be included in the output?
##' @param verbose run-time information?
##' @details
##' \code{run_abm} simulated the spread of a transmissible agent through
##' a hospital.
##' When testing events are given in \code{data}, all patients on the given unit are tested.
##' Patients are screened on admission.
##' @return
##' \code{run_abm} returns a \code{\link[tibble]{tibble}} with one row per testing event.
##' This contains information on the test result, true colonization status, and location of the tested patient.
##' @example examples/run_abm.R
NULL

screen_test <- function (istat, alpha, beta) {
  if (istat==0L) {
    sample(c(0L,1L),size=1L,prob=c(1-alpha,alpha))
  } else if (istat==1L) {
    sample(c(0L,1L),size=1L,prob=c(beta,1-beta))
  } else {                     #nocov
    pStop("c'est impossible!") #nocov
  }                            #nocov
}

##' @rdname abm
##' @importFrom progress progress_bar
##' @importFrom dplyr coalesce bind_rows mutate
##' @importFrom tibble as_tibble
##' @importFrom stats rexp
##' @export
run_abm <- function (
  data,
  b = 0.03, gamma = 0.02, lambda0 = 0,
  p0 = 0.05,
  alpha = 0.01, beta = 0.15,
  adm_eff = 0, status_changes = FALSE,
  verbose = getOption("verbose", TRUE)
) {

  if (isTRUE(verbose)) {
    prog <- progress_bar$new(total=nrow(data))
    prog$tick(0)
  }
  if (!all(diff(data$time)>=0))
    pStop("in ",sQuote("data"),", time should be nondecreasing.")

  ## recode events
  event_types <- c("admit"=0L,"admission"=0L,
    "discharge"=1L,"transfer"=2L,"test"=3L)
  data$event <- match(data$event,names(event_types))
  data$event <- event_types[data$event]

  ## recode patient using integers
  patients <- unique(data$patient)
  data$patient <- factor(data$patient,levels=patients)
  data$patient <- as.integer(data$patient)
  npat <- length(patients)

  ## recode unit using integers
  units <- grep("out",unique(data$unit),
    invert=TRUE,ignore.case=TRUE,value=TRUE)
  data$unit <- factor(data$unit,levels=units)
  data$unit <- as.integer(data$unit)
  nunit <- length(units)

  ## patient-specific colonization status and location
  istat <- rep(NA_integer_,npat)
  loc <- rep(NA_integer_,npat)

  ## unit-specific population sizes
  N <- integer(nunit)
  I <- integer(nunit)

  events <- list()
  i <- 1L
  t <- data$time[i]

  while (i <= nrow(data)) {
    x <- data[i,]
    tend <- x$time
    if (tend > t) {
      lambda <- coalesce(b*I/N,0)+lambda0
      col_rate <- lambda*(N-I)
      tot_col_rate <- sum(col_rate)
      decol_rate <- gamma*I
      tot_decol_rate <- sum(decol_rate)
      tnext <- t+rexp(n=1,rate=tot_col_rate+tot_decol_rate)
      while (tnext < tend) {
        type <- sample.int(2L,size=1L,prob=c(tot_col_rate,tot_decol_rate))
        if (type==1L) { # colonization event
          u <- sample.int(nunit,size=1L,prob=col_rate)
          p <- which(!is.na(loc) & loc==u & istat==0L)
          k <- p[sample.int(length(p),size=1L)]
          istat[k] <- 1L
          I[u] <- I[u]+1L
        } else if (type==2) { # decolonization event
          u <- sample.int(nunit,size=1L,prob=decol_rate)
          p <- which(!is.na(loc) & loc==u & istat==1L)
          k <- p[sample.int(length(p),size=1L)]
          istat[k] <- 0L
          I[u] <- I[u]-1L
        }
        t <- tnext

        if (isTRUE(status_changes)) {
          events |>
            c(
              list(list(time=t,patient=k,unit=u,
                event=type,result=NA_integer_,status=istat[k])
              )) -> events
        }

        lambda <- coalesce(b*I/N,0)+lambda0
        col_rate <- lambda*(N-I)
        tot_col_rate <- sum(col_rate)
        decol_rate <- gamma*I
        tot_decol_rate <- sum(decol_rate)
        tnext <- t+rexp(n=1,rate=tot_col_rate+tot_decol_rate)
      }
    }

    if (x$event==0L) { # admission event
      dest <- x$unit
      k <- x$patient
      loc[k] <- dest
      istat[k] <- sample(c(0L,1L),size=1L,prob=c(1-p0,p0))
      N[dest] <- N[dest]+1L
      if (isTRUE(istat[k]==1L)) I[dest] <- I[dest]+1L
      ## test on admission:
      if (adm_eff > 0 && (adm_eff >= 1 || runif(1) < adm_eff)) {
        r <- screen_test(istat=istat[k],alpha=alpha,beta=beta)
        testevent <- list(time=t,patient=k,unit=dest,
          event=3L,result=r,status=istat[k])
        events |> c(list(testevent)) -> events
      }
    } else if (x$event==1L) { # discharge event
      k <- x$patient
      src <- loc[k]
      if (is.na(src))
        pStop("patient ",patients[k]," cannot be discharged!")
      if (isTRUE(istat[k]==1L)) I[src] <- I[src]-1L
      N[src] <- N[src]-1L
      loc[k] <- NA_integer_
      istat[k] <- NA_integer_
    } else if (x$event==2L) { # transfer event
      k <- x$patient
      src <- loc[k]
      if (is.na(src))
        pStop("patient ",patients[k]," cannot be transferred!")
      dest <- x$unit
      if (isTRUE(istat[k]==1L)) {
        I[src] <- I[src]-1L
        I[dest] <- I[dest]+1L
      }
      N[src] <- N[src]-1L
      N[dest] <- N[dest]+1L
      loc[k] <- dest
    } else if (x$event==3L) { # test event
      src <- x$unit
      p <- which(!is.na(loc) & loc==src)
      testevents <- vector(mode="list",length=length(p))
      j <- 1
      for (k in p) {
        r <- screen_test(istat=istat[k],alpha=alpha,beta=beta)
        testevents[[j]] <- list(time=t,patient=k,unit=src,
          event=3L,result=r,status=istat[k])
        j <- j+1
      }
      events |> c(testevents) -> events
    } else {
      pStop("unrecognized event in line ",i,".")
    }
    if (isTRUE(verbose)) prog$tick()
    t <- tend
    i <- i+1
  }

  events |>
    lapply(as.data.frame) |>
    bind_rows() |>
    as_tibble() |>
    mutate(
      patient=patients[patient],
      unit=units[unit],
      event=c("col","decol","test")[event]
    )
}
