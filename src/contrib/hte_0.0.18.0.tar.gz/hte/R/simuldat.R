##' simuldat
##'
##' Simulate hospital movement, testing, and isolation data.
##'
##' @name simuldat
##' @rdname simuldat
##' @include package.R
##' @family simulated data
##' @family independent model
##' @description
##' \code{simuldat} simulates data representing the flow of a body of
##' patients through a hospital over a specified window of time.
##'
##' @param nbeds upper and lower bounds on number of beds
##' @param arrival Poisson arrival rate of new patients
##' @param window window of simulation
##' @param units a named list with one entry per unit.
##' Each entry is itself a list with the parameters of the Gamma-distribution for the duration of stay in the unit.
##' @param visits list containing parameters of a negative binomial distribution
##' for the number of visits per patient.
##' @param uperv list containing parameters for a negative binomial distribution
##' for the number of units visited per visit.
##' @param min_dur minimum duration of stay in any unit
##' @param testing_freq named numeric vector of unit-specific
##' testing frequencies.
##' @param isolation list containing parameters of the isolation model
##' @param infection parameters of the infection model
##' @param alpha,beta false positive and negative testing error rates
##' @param verbose run-time information?
##' @importFrom progress progress_bar
##' @importFrom stats rpois runif
##' @importFrom lubridate as_datetime duration
##' @importFrom dplyr filter bind_rows arrange mutate pull
##' @example examples/simuldat.R
##' @export
simuldat <- function (
  nbeds = c(50,60),
  arrival = 20,
  window = c("1999-12-31T23:59:59+0000","2003-01-01T00:00:00+0000"),
  units = list(
    A = list(shape = 10, scale = 2/10),
    B = list(shape = 5, scale = 0.5/5),
    C = list(shape = 1, scale = 0.5/1),
    D = list(shape = 1, scale = 3/1),
    E = list(shape = 0.2, scale = 8/0.2),
    out = list(shape = 0.5, scale = 300/0.5)
  ),
  visits = list(size = 0.5, mu = 9),
  uperv = list(size=1, mu = 0.5),
  min_dur = 1/24,
  testing_freq = c(A = NA, B = NA, C = 1/7, D = 1/7, E = 1/7, out = NA),
  isolation = list(on = 1/50, off = 1/50),
  infection = list(
    lambda = c(A=0.01, B=0.02, C=0.001, D=0.5, E=0.1, out=0.05),
    gamma = 0.01, p0 = 0.1, isol_factor = 0.2
  ),
  alpha = 0.02, beta = 0.1,
  verbose = getOption("verbose", TRUE)
) {
  if (length(nbeds)!=2L) pStop("must supply upper and lower targets.")
  tw <- c(0,as.double(diff(as_datetime(window)),units="days"))
  ## New patient arrival times
  tarr <- sort(
    runif(
      n=rpois(n=1L,lambda=arrival*diff(tw)),
      min=tw[1L],max=tw[2L]
    )
  )
  dat <- tibble()
  pat <- 1L # next patient id
  k <- 1L   # index of data frame
  nin <- 0L # number of patients in hospital
  ndeny <- 0L # number of visits denied
  if (verbose) {
    pb <- progress_bar$new(total=length(tarr))
    pb$tick(0)
  }
  for (t in tarr) {
    if (nin < nbeds[1L]) {
      dat |>
        bind_rows(
          simul_patient(
            pat,
            t0=t,tf=tw[2L],
            units=units,visits=visits,uperv=uperv,
            testing_freq=testing_freq,
            isolation=isolation,
            infection=infection,
            alpha=alpha,beta=beta,
            min_dur=min_dur
          )
        ) |> arrange(time) -> dat
      pat <- pat+1L
    }
    while (dat$time[k] < t) {
      if (dat$event[k]=="admit") {
        if (nin < nbeds[2L]) {
          nin <- nin+1L
        } else {
          p <- dat$patient[k]
          v <- dat$visit[k]
          dat |>
            filter(patient!=p | visit!=v) |>
            arrange(time) -> dat
          ndeny <- ndeny+1L
          k <- k-1L
        }
      } else if (dat$event[k]=="discharge") {
        nin <- nin-1L
      }
      k <- k+1L
    }
    if (verbose) pb$tick()
  }
  dat |>
    filter(event!="test",event!="stop") |>
    pull(time) |>
    diff() |>
    min() -> dt
  if (dt <= 0) pStop("yikes!")
  dat |>
    mutate(
      patient=as.character(patient),
      date=as_datetime(window[1L])+duration(days=time)
    ) |>
    select(patient,visit,date,time,event,unit,result,isol,infected) |>
    arrange(patient,date) -> dat
  row.names(dat) <- NULL
  if (verbose) cat(ndeny,"admissions denied\n")
  dat
}

##' @name simul_patient
##' @rdname simuldat
##' @description \code{simul_patient} simulates a single patient's
##' history of movement, testing, isolation, and infection.
##' @include package.R
##' @param patient patient name or number
##' @param t0,tf initial and final times of patient itinerary
##' @importFrom dplyr lead
##' @importFrom dplyr mutate filter select bind_rows arrange
##' @importFrom tibble tibble
##' @export
simul_patient <- function (
  patient, t0, tf,
  units, visits, uperv, min_dur,
  testing_freq, isolation,
  infection, alpha, beta
) {
  patient_itinerary(
    patient=patient,
    t0=t0,tf=tf,
    units=units,
    visits=visits,
    uperv=uperv,
    min_dur=min_dur
  ) |>
    ## testing
    add_tests(freq=testing_freq) |>
    ## add stop entry for patients in hospital at end of window
    bind_rows(tibble(patient=patient,time=tf,event="stop")) |>
    arrange(time) |>
    ## isolation
    add_isol(isolation) |>
    mutate(
      unit=coal_last(unit),
      visit=coal_last(visit),
      isol=as.integer(isol)
    ) |>
    ## infection status
    add_infect(infection) |>
    ## test results
    add_result(alpha=alpha,beta=beta) |>
    ## drop redundant stop events
    filter(event!="stop" | lag(event)!="discharge") |>
    select(patient,visit,time,event,unit,result,isol,infected)
}

## the following line quiets concerns of
## R CMD check regarding the foreach iterator variables
##' @importFrom utils globalVariables
c(
  "isol","state","patient","visit","event","infected","result",
  "enterwk","departwk"
) |>
  utils::globalVariables()

##' @name indep_infect
##' @rdname simuldat
##' @include package.R
##' @param lambda force of infection
##' @param gamma recovery rate
##' @param p0 initial probability of infection
##' @param isol_factor reduction in susceptibility due to isolation
##' @param times times at which status is reported
##' @param loc location of patient at each time
##' @param isol isolation status
##' @return infection status vector
##' @importFrom stats rbinom
##' @export
indep_infect <- function (lambda, gamma, p0, isol_factor, times, loc, isol) {
  if (any(diff(times)<0))
    pStop("'times' should be increasing!")
  p <- numeric(length(times))
  p[1L] <- rbinom(n=1L,prob=p0,size=1L)
  dt <- diff(times)
  for (k in seq_len(length(times)-1L)) {
    u <- loc[k]
    ell <- lambda[u]*((1-isol[k])+isol[k]*isol_factor)
    s <- ell+gamma
    peq <- ell/s
    a <- exp(-s*dt[k])
    p[k+1L] <- rbinom(n=1L,prob=a*p[k]+(1-a)*peq,size=1L)
  }
  p
}

##' @importFrom dplyr mutate
add_infect <- function (dat, model) {
  ## assumes dat is arranged in order of increasing time
  dat |>
    mutate(
      infected=do.call(
        indep_infect,
        c(model,list(time=time,loc=unit,isol=isol))
      )
    )
}

##' @importFrom dplyr bind_rows arrange mutate reframe case_when filter select coalesce
add_isol <- function (dat, model) {
  ## assumes dat is arranged in order of increasing time
  dat |>
    reframe(
      twostate(
        on=model$on,
        off=model$off,
        t0=min(time),
        tf=max(time)
      )
    ) |>
    bind_rows(dat) |>
    arrange(time) |>
    mutate(
      event=case_when(
        state==1L~"isolate",
        state==-1L~"release",
        TRUE~event
      ),
      isol=cumsum(coalesce(state,0)),
      patient=coal_last(patient),
      visit=coal_last(visit),
      unit=coal_last(unit),
      isol=if_else(unit=="out",0,isol)
    ) |>
    filter(
      unit!="out" | is.na(state)
    ) |>
    select(-state)
}

##' @importFrom dplyr select mutate filter rowwise reframe ungroup bind_rows arrange
add_tests <- function (dat, freq) {
  dat |>
    select(patient,visit,unit,time) |>
    mutate(
      enterwk=ceiling(time*freq[unit]),
      departwk=floor(lead(time)*freq[unit])
    ) |>
    filter(!is.na(enterwk),enterwk<=departwk) -> x
  if (nrow(x) > 0L) {
    x |>
      rowwise() |>
      reframe(
        patient=patient,
        visit=visit,
        unit=unit,
        time=seq(from=enterwk,to=departwk,by=1L)/freq[unit],
        event="test"
      ) |>
      ungroup() |>
      bind_rows(dat) |>
      arrange(time)
  } else {
    dat
  }
}

##' @importFrom stats rbinom
##' @importFrom dplyr mutate if_else
add_result <- function (dat, alpha, beta) {
  ## assumes dat is arranged in order of increasing time
  dat |>
    mutate(
      result=if_else(
        event=="test",
        rbinom(
          n=length(infected),
          size=1L,
          prob=(1-infected)*alpha+infected*(1-beta)
        ),
        NA_integer_
      )
    )
}

## Construct patient itinerary
##' @importFrom stats rnbinom rgamma
##' @importFrom dplyr lag
##' @importFrom tibble tibble
##' @importFrom utils head
patient_itinerary <- function (
  patient, t0, tf, units, visits, uperv, min_dur
) {
  ## names of hospital units
  U <- setdiff(names(units),"out")
  ## number of visits
  nvisit <- 1+do.call(rnbinom,c(n=1,visits))
  ## number of units visited
  nunit <- 1+do.call(rnbinom,c(n=nvisit,uperv))
  ## itinerary
  lapply(
    nunit,
    \(n) c(unique(sample(U,size=n,replace=TRUE)),"out")
  ) |>
    unlist() -> itin
  ## duration in each unit
  lapply(
    units[itin],
    \(x) do.call(rgamma,c(n=1,x))
  ) |>
    unlist() -> dur
  ## construct output
  tibble(
    patient=patient,
    dur=dur,
    unit=names(dur)
  ) |>
    mutate(
      dur=pmax(dur,min_dur), # minimum allowable duration
      event=case_when(
        is.na(lag(unit))~"admit",
        lag(unit)=="out"~"admit",
        unit=="out"~"discharge",
        TRUE~"transfer"
      ),
      visit=cumsum(event=="admit"),
      time=cumsum(c(t0,head(dur,-1L)))
    ) |>
    filter(time<tf) |>
    select(patient,visit,time,event,unit)
}
