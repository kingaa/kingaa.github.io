##' Stateful objective functions
##'
##' Convenience functions for constructing and working with stateful objective functions (\sQuote{stobfun}-class objects).
##'
##' @section Construction and usage of stateful objective functions:
##' A stateful objective function is an ordinary function that can be used as an objective function in an optimization problem.
##' In particular, it can be passed to optimizers such as \code{\link[stats]{optim}}, \code{\link[subplex]{subplex}}, or \code{\link[nloptr]{nloptr}}.
##' It is stateful in the sense that it remembers the argument with which it was last called.
##'
##' To construct a stateful objective function, call the constructor function for the model of interest.
##' The constructor function requires that you pass a vector of model parameters: this gives the default parameter values.
##' It also requires that you pass the data and the names of the parameters that you wish to estimate.
##' The constructor will return an object of class \sQuote{stobfun}.
##'
##' Having constructed a \sQuote{stobfun} stateful objective function, you can pass this to any suitable optimizer.
##' Once the optimizer has returned, \bold{it is important that you call the function one last time, at the parameters the optimizer has returned} (see examples).
##' This ensures that the stored parameters are those at the (putative) optimum.
##' You can retrieve these parameters via a call to \code{coef}.
##'
##' @name stobfun
##' @rdname stobfun
##' @include package.R
##' @family stateful objective functions
##' @param log character; names of parameters to log transform.
##' @param logit character; names of parameters to logit transform.
##' @param est character: names of parameters to be estimated
##' @param params vector of parameters
##' @param objfun underlying objective function
##' @param data data
##' @param embed embedding (see \code{\link{embedding}}).
##' @param ... When furnished to \code{stobfun}, additional arguments are passed to \code{objfun}.
##' When furnished to \code{embedding}, arguments define th embedding.
##' When furnished to \code{\link[=coef.stobfun]{coef}}, additional arguments are ignored.
##' @details
##' \code{objfun} will be called as \code{objfun(theta,data)}, where
##' \code{theta} is the nested list constructed according to the given specifications
##' and \code{data} is the data.
##'
NULL

##' @rdname stobfun
##' @export
stobfun <- function (
  embed, params, est = character(0),
  log = character(0), logit = character(0),
  objfun, data, ...
) {
  ep <- sys.parent(1L) # for error messages
  ## tutto a posto?
  tryCatch(
    name_check(embed,params,est),
    error=function (e) {
      pStop(conditionMessage(e),which=ep)
    }
  )
  ## parameter transformations
  tfs <- tryCatch(
    transf_fns(log=log,logit=logit,est=est),
    error=function (e) {
      pStop(conditionMessage(e),which=ep)
    }
  )
  tparams <- tfs$forward(params)
  idx <- match(est,names(tparams))
  list(
    quote(objfun),
    theta=quote(theta),
    data=quote(data),
    ...
  ) |>
    as.call() -> fncall
  ## the stateful objective function itself
  ofun <- function (par = numeric(0)) {
    tparams[idx] <<- par
    theta <- embed(tfs$inverse(tparams))
    length(theta) # to forestall 'R CMD check' warning about unused variable
    eval(fncall)
  }
  ## the environment for the stobfun
  environment(ofun) <- list2env(
    list(
      tparams=tparams,
      embed=embed,
      tfs=tfs,
      idx=idx,
      objfun=objfun,
      fncall=fncall,
      data=data
    ),
    parent=parent.env(environment())
  )
  structure(ofun,class="stobfun")
}

##' @rdname stobfun
##' @param filtfun the function that actually applies the filter
##' @export
filterfun <- function (
  embed, params, filtfun, data, ...
) {
  ep <- sys.parent(1L) # for error messages
  ## tutto a posto?
  tryCatch(
    name_check(embed,params),
    error=function (e) {
      pStop(conditionMessage(e),which=ep)
    }
  )
  ## the function call
  list(
    quote(filtfun),
    theta=quote(theta),
    data=quote(data),
    ...
  ) |>
    as.call() -> fncall
  ## the filtering function
  fun <- function (par) {
    theta <- embed(par)
    length(theta) # to forestall 'R CMD check' warning about unused variable
    eval(fncall)
  }
  ## the environment for the stobfun
  environment(fun) <- list2env(
    list(
      embed=embed,
      filtfun=filtfun,
      fncall=fncall,
      data=data
    ),
    parent=parent.env(environment())
  )
  fun
}

##' @rdname stobfun
##' @return
##' \code{transf_fns} returns a list of two functions.
##' The first is the transformation to the estimation scale;
##' the second is its inverse.
##' @importFrom stats plogis qlogis
##' @export
transf_fns <- function (
  log = character(0),
  logit = character(0),
  est = character(0)
) {
  if (length(intersect(log,logit))>0L)
    pStop("cannot both log and logit transform a parameter!",which=NULL)
  log <- intersect(est,log)
  logit <- intersect(est,logit)
  if (length(log)+length(logit)>0L) {
    list(
      forward=function (params) {
        if (length(log)>0L) params[log] <- log(params[log])
        if (length(logit)>0L) params[logit] <- qlogis(params[logit])
        params
      },
      inverse=function (params) {
        if (length(log)>0L) params[log] <- exp(params[log])
        if (length(logit)>0L) params[logit] <- plogis(params[logit])
        params
      }
    )
  } else {
    list(forward=identity,inverse=identity)
  }
}

##' @rdname stobfun
##' @return \code{embedding} returns the embedding function corresponding to the given specification.
##' @importFrom utils as.relistable relist
##' @export
embedding <- function (...) {
  pnames <- unlist(as.relistable(list(...)))
  function (params) {
    relist(params[pnames],skeleton=attr(pnames,"skeleton"))
  }
}

name_check <- function (f, params, est = character(0)) {
  nm <- unique(environment(f)$pnames)
  if (!all(nm %in% names(params))) {
    pStop(
      sQuote("params")," must include all of ",
      paste(sQuote(nm),collapse=", "),".",
      which=NULL
    )
  }
  if (!all(est %in% names(params))) {
    pStop(
      sQuote("est")," must name parameters in ",
      sQuote("params"),".",
      which=NULL
    )
  }
}

##' @rdname stobfun
##' @aliases coef,stobfun-method
##' @return \code{coef(f)} returns the parameter vector corresponding to the last call of the stateful objective function \code{f}.
##' @param object \sQuote{stobfun}-class stateful objective function
##' @importFrom stats coef
##' @export
coef.stobfun <- function (object, ...) {
  e <- environment(object)
  e$tfs$inverse(e$tparams)
}
