library(hte)

try(transf_fns(log=c("A","B"),logit=c("B","C")))

f <- transf_fns(log=c("A","B"),logit=c("C","D"),est=c("A","B","C","D"))
f$forward(c(A=exp(1),B=exp(2),C=plogis(3),D=plogis(4)))
f$forward(f$inverse(c(A=1,B=2,C=3,D=4)))
f$inverse(f$forward(c(A=1,B=2,C=0.5,D=0.1)))

f <- transf_fns(log=c("A","B"),logit=c("C","D"),est=c("A","C"))
f$forward(c(A=exp(1),C=plogis(3)))
f$forward(f$inverse(c(A=1,C=3)))
f$inverse(f$forward(c(A=1,C=0.5)))
f$forward(c(A=exp(1)))
f$forward(f$inverse(c(A=1)))
f$inverse(f$forward(c(A=1)))
f$forward(c(A=exp(1),B=exp(2),C=plogis(3),D=plogis(4)))
f$forward(f$inverse(c(A=1,B=2,C=3,D=4)))
f$inverse(f$forward(c(A=1,B=2,C=0.5,D=0.1)))


