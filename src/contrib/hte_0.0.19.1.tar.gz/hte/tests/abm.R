library(tidyverse)
library(hte)

png(filename="abm-%02d.png",width=7,height=7,units="in",res=200)

set.seed(339613584)

sim_pat_mov |>
  filter(time<100) |>
  bind_rows(
    expand_grid(
      unit=c("A","B","C"),
      time=seq(7,100,by=7),
      event="test"
    )
  ) |>
  arrange(time) |>
  run_abm(adm_eff=0.5) |>
  filter(time>0) -> tt1

tt1 |> count(event)
tt1 |> count(time) |> filter(n>1)

sim_pat_mov |>
  bind_rows(tt1) |>
  arrange(time) |>
  select(-result,-status) |>
  run_abm() -> tt2

sim_pat_mov |>
  bind_rows(tt2) |>
  arrange(time) |>
  group_by(patient) |>
  slice(n()) |>
  ungroup() |>
  count(event)

sim_pat_mov |>
  bind_rows(tt2) |>
  arrange(time) |>
  filter(patient %in% c("2594","1111"))

bind_rows(
  sim_pat_mov,
  expand_grid(
    time=seq(70,1827,by=7),
    unit=LETTERS[1:9],
    event="test"
  )
) |>
  arrange(time) |>
  filter(event != "test" | time >= 70) |>
  filter(time<100) |>
  run_abm(
    b=0.05,gamma=0.002,p0=0.08,
    alpha=0.003,beta=0.14,
    adm_eff=0
  ) -> x

x |>
  bind_rows(
    sim_pat_mov
  ) |>
  arrange(time) -> simdat

simdat |>
  group_by(patient) |>
  slice(n()) |>
  ungroup() |>
  count(event)

simdat |>
  group_by(patient) |>
  mutate(last=lag(unit)) |>
  ungroup() |>
  filter(event=="test") |>
  filter(unit!=last)

dev.off()
