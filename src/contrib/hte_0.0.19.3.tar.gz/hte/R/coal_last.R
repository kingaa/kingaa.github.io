##' @title Coalesce with last
##' @name coal_last
##' @rdname coal_last
##' @include package.R
##' @param x vector
##' @description Fills NA with previous non-NA.
##' @export
coal_last <- function (x) {
  if (length(x)>1L) {
    for (k in seq_len(length(x)-1L)) {
      if (is.na(x[k+1L])) x[k+1L] <- x[k]
    }
  }
  x
}
