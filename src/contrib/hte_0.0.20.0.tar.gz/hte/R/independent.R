##' Independent infection model
##'
##' Model under which each patient's trajectory of infection is
##' independent, conditional on the force of infection.
##'
##' Parameters in the model include:
##' \describe{
##'   \item{lambda}{force of infection. In the homogeneous model, this is constant across units in the hospital; in the unit-specific model, there is one value of lambda for each unit.}
##'   \item{lambda.out}{force of infection outside the hospital}
##'   \item{gamma}{recovery rate}
##'   \item{alpha,beta}{false positive and negative probabilities}
##'   \item{p0}{probability of infection on admission}
##'   \item{isol_factor}{multiplicative effect of contact isolation on susceptibility}
##'   \item{eta}{additional information on infection status}
##' }
##' @name independent
##' @rdname independent
##' @include bfilter.R stobfun.R
##' @family independent model
##' @family stateful objective functions
##' @param data patient movement, isolation, and testing data
##' @param params named vector of parameters
##' @param est names of parameters to estimate
##' @example examples/indep.R
NULL

##' @rdname independent
##' @details \code{indep_homog_filter} runs a Bernoulli filter for the
##' independent model with a global lambda and gamma.
##' @export
indep_homog_filter <- function (params, data) {
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  nunit <- length(dat$unitnames)
  filterfun(
    embedding(
      lambda=c("lambda.out",rep.int("lambda",nunit-1L)),
      gamma=rep.int("gamma",nunit),
      p0=rep.int("p0",nunit),
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor",
      eta="eta"
    ),
    params=params,
    data=dat,
    filtfun=indep_filter
  ) -> f
  f(params)
}

##' @rdname independent
##' @details \code{indep_homog_objfun} is a stateful objective
##' function for the independent model with a global lambda and gamma.
##' @export
indep_homog_objfun <- function (params, data, est = character(0)) {
  ## reformat data & extract unit names
  data |> filter_order() |> Bfilter_setup() -> dat
  stobfun(
    embedding(
      lambda=c("lambda.out",rep.int("lambda",dat$nunit-1L)),
      gamma=rep.int("gamma",dat$nunit),
      p0=rep.int("p0",dat$nunit),
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor",
      eta="eta"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("lambda","lambda.out","gamma","isol_factor","eta"),
    logit=c("alpha","beta","p0"),
    objfun=nll_indep
  )
}

##' @rdname independent
##' @details \code{indep_unit_spec_filter} runs a Bernoulli filter
##' for the independent model with a unit-specific lambda.
##' @export
indep_unit_spec_filter <- function (params, data) {
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  lambdas <- paste("lambda",dat$unitnames,sep=".")
  p0s <- paste("p0",dat$unitnames,sep=".")
  filterfun(
    embedding(
      lambda=lambdas,
      gamma="gamma",
      p0=p0s,
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor",
      eta="eta"
    ),
    params=params,
    data=dat,
    filtfun=indep_filter
  ) -> f
  f(params)
}

##' @rdname independent
##' @details \code{indep_unit_spec_objfun} is a stateful objective
##' function for the independent model with unit-specific lambda.
##' @export
indep_unit_spec_objfun <- function (params, data, est = character(0)) {
  data |> filter_order() |> Bfilter_setup() -> dat
  lambdas <- paste("lambda",dat$units,sep=".")
  p0s <- paste("p0",dat$units,sep=".")
  stobfun(
    embedding(
      lambda=lambdas,
      gamma="gamma",
      p0=p0s,
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor",
      eta="eta"
    ),
    params=params,
    data=dat,
    est=est,
    log=c(lambdas,"gamma","isol_factor","eta"),
    logit=c("alpha","beta",p0s),
    objfun=nll_indep
  )
}

## filter for the independent model
indep_filter <- function (theta, data) {
  nunit <- length(data$unitnames)
  lambda <- tryCatch(
    extend_vec(theta$lambda,nunit,data$dim[4L]),
    error = function (e) pStop("lambda: ",conditionMessage(e),which=NULL)
  )
  gamma <- tryCatch(
    extend_vec(theta$gamma,nunit,data$dim[4L]),
    error = function (e) pStop("gamma: ",conditionMessage(e),which=NULL)
  )
  data |>
    Bernoulli_filter_internal(
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor,
      eta=theta$eta
    )
}

## negative log likelihood under the independent model
nll_indep <- function (theta, data) {
  lambda <- tryCatch(
    extend_vec(theta$lambda,data$nunit),
    error = function (e) pStop("lambda: ",conditionMessage(e),which=NULL)
  )
  gamma <- tryCatch(
    extend_vec(theta$gamma,data$nunit),
    error = function (e) pStop("gamma: ",conditionMessage(e),which=NULL)
  )
  data$data |>
    vapply(
      Bfilter_internal,
      double(1L),
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor,
      eta=theta$eta
    ) |>
    sum() -> ll
  -ll
}
