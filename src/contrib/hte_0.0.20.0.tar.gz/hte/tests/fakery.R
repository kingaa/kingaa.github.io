options(tidyverse.quiet=TRUE,digits=3)
library(tidyverse)
library(lubridate)
library(hte)

png(filename="fakery-%02d.png",width=7,height=7,units="in",res=200)

set.seed(339613584)

simuldat(
  window=c(
    "2020-01-30T23:30:00+0000",
    "2020-02-14T00:30:00+0000"
  )
) -> dat

stopifnot(
  `admission condition violation`=dat |>
    group_by(patient,visit) |> slice_head() |>
    filter(event!="admit") |> nrow()==0,
  `discharge condition violation`=dat |>
    group_by(patient,visit) |> slice_tail() |>
    filter(event!="discharge",event!="stop") |> nrow()==0,
  `unit violation`=dat |> filter(is.na(unit)) |> nrow()==0,
  `event violation`=dat |> filter(is.na(event)) |> nrow()==0
)

dat |>
  group_by(patient,visit) |>
  summarize(dur=max(time)-min(time)) |>
  ungroup() |>
  group_by(patient) |>
  summarize(dur=sum(dur)) |>
  ggplot(aes(x=log10(dur)))+
  geom_histogram(bins=20)+
  labs(title="total duration of hospitalization")+
  theme_bw()

dat |>
  group_by(patient,visit) |>
  summarize(dur=max(time)-min(time)) |>
  ungroup() |>
  ggplot(aes(x=log10(dur)))+
  geom_histogram(bins=40)+
  labs(title="duration of hospital visit")+
  theme_bw()

dat |>
  arrange(time) |>
  mutate(
    dn=case_when(
      event=="admit"~1L,
      event=="discharge"~-1L,
      TRUE~0L
    ),
    occ=cumsum(dn)
  ) |>
  ggplot(aes(x=date,y=occ))+
  geom_step()+
  labs(title="hospital occupancy")+
  theme_bw()

dat |>
  filter(event=="test") |>
  select(infected,result) |>
  count(infected,result) |>
  group_by(infected) |>
  mutate(prob=n/sum(n)) |>
  ungroup()

dat |> slice(50:60)

dev.off()
