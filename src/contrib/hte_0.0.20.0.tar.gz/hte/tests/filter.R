options(tidyverse.quiet=TRUE,digits=3)
library(tidyverse)
library(lubridate)
library(hte)

set.seed(626292345)

fake_data |>
  filter(time < 10) |>
  arrange(patient,time) -> dat

theta <- list(
  lambda=c(out=0,A=0.01,B=0.1,C=0.2,D=0.3,E=0.5),
  gamma=c(out=0.1,A=0.3,B=0.1,C=0.1,D=0.1,E=0.1),
  p0=c(out=0.2,A=0.2,B=0.5,C=0.2,D=0.2,E=0.2),
  isol_factor=0.1,
  alpha=0.05,
  beta=0.2,
  eta=0.5
)

dat |>
  Bfilter(theta) -> ll1
sum(ll1)

dat |>
  group_by(patient) |>
  filter(sum(event=="test")>0) |>
  ungroup() |>
  group_split(patient) |>
  sapply(
    \(x) {
      U <- c("out",setdiff(sort(unique(x$unit)),"out"))
      Bernoulli_filter(
        x,
        lambda=theta$lambda[U],
        gamma=theta$gamma[U],
        theta
      ) -> f
      sum(f$logLik)
    }
  ) -> ll2

dat |>
  Bernoulli_filter(
    lambda=theta$lambda,
    gamma=theta$gamma,
    theta
  ) -> f
f |> filter(logLik!=0) |> pull(logLik) -> ll3

stopifnot(
  all.equal(ll1,ll2),
  all.equal(ll2,ll3),
  all.equal(sum(ll1),sum(ll3))
)

f |> filter(time>6) |> print(n=20)

dat |>
  filter(patient==19) -> p19
p19

p19 |>
  Bernoulli_filter(
    lambda=theta$lambda[c("out","A","D")],
    gamma=theta$gamma[c("out","A","D")],
    theta
  ) |>
  pull(logLik) |>
  sum()

s <- theta$lambda["D"]+theta$gamma["D"]
peq <- theta$lambda["D"]/s
a <- exp(-s*(p19$time[2]-p19$time[1]))
p <- (1-a)*peq+a*theta$p0
log((1-p)*theta$alpha+p*(1-theta$beta))
