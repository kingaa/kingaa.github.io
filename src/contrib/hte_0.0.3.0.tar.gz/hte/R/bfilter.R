##' Bernoulli filter
##'
##' Filter the individual patient data with given forces of infection,
##' recovery rates, and test characteristics.
##' 
##' @name Bernoulli_filter
##' @rdname bernoulli_filter
##' @details \code{Bernoulli_filter} runs a Bernoulli filter,
##' updating the expected prevalence.
##' It returns the log likelihood, occupancy, and expected prevalences.
##' @return \code{Bernoulli_filter} returns a \code{\link[tibble]{tibble}}
##' containing the expected prevalences (for both isolated and un-isolated
##' patients), unit occupancy, force of infection, and conditional log
##' likelihood for each unit at each event time.
##' The sum of the log likelihood column (\code{logLik}) is the log
##' likelihood of the data.
##' @include package.R
##' @importFrom dplyr mutate arrange select group_split group_by
##' @importFrom tibble rowid_to_column tibble
##' @importFrom tidyr expand_grid
##' @param data data set
##' @param theta list of parameters
##' @param lambda unit-specific force of infection
##' @param gamma unit-specific recovery rate
##' @example examples/bfilt.R
##' @export
Bernoulli_filter <- function (data, lambda, gamma, theta) {
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  lg <- extend_lambda_gamma(
    lambda=lambda,
    gamma=gamma,
    nunit=length(dat$unitnames),
    ngrid=dat$ngrid
  )
  dat |>
    Bernoulli_filter_internal(
      lambda=lg$lambda,
      gamma=lg$gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    )
}

filter_order <- function (data) {
  ## names of all units; "out" must be first
  U <- c("out",setdiff(sort(unique(data$unit)),"out"))
  data |>
    mutate(
      patient=factor(patient),
      unit=factor(unit,levels=U),
      loc=as.integer(unit)
    ) |>
    arrange(time,patient) |>
    rowid_to_column() |>
    arrange(patient,rowid)
}

## Do one-time setup for Bernoulli filtering
## This assumes the data have been ordered using
## 'filter_order'
Bernoulli_filter_setup <- function (data) {
  times <- sort(data$time)
  units <- levels(data$unit)
  grid <- expand_grid(
    time=as.double(times),
    unit=units
  )
  list(
    patno=as.integer(data$patient),
    result=as.integer(data$result),
    isol=as.integer(data$isol),
    rowid=as.integer(data$rowid),
    loc=as.integer(data$loc),
    dim=as.integer(
      c(nrow(data),length(units),length(times))
    ),
    time=grid$time,
    unit=grid$unit,
    ngrid=nrow(grid),
    unitnames=units
  )
}

## This function extends the furnished lambda, gamma into vectors
## of the appropriate size.
extend_lambda_gamma <- function (lambda, gamma, nunit, ngrid) {
  nlambda <- length(lambda)
  if (nlambda!=1L && nlambda!=nunit && nlambda!=ngrid)
    stop(sQuote("lambda")," is wrong length.")
  if (nlambda != ngrid)
    lambda <- rep_len(lambda,ngrid)
  ngamma <- length(gamma)
  if (ngamma!=1L && ngamma!=nunit && ngamma!=ngrid)
    stop(sQuote("gamma")," is wrong length.")
  if (ngamma != ngrid)
    gamma <- rep_len(gamma,ngrid)
  list(
    lambda=as.double(lambda),
    gamma=as.double(gamma)
  )
}

## 'data' is assumed to be pre-processed by 'filter_order'
Bernoulli_filter_internal <- function (
  data, lambda, gamma,
  p0, alpha, beta, isol_factor
) {
  .C(
    "Bernoulli_Filter",
    alpha=as.double(alpha),
    beta=as.double(beta),
    p0=as.double(p0),
    isol_factor=as.double(isol_factor),
    patno=data$patno,
    result=data$result,
    isol=data$isol,
    rowid=data$rowid,
    loc=data$loc,
    dim=data$dim,
    lambda=as.double(lambda),
    gamma=as.double(gamma),
    time=data$time,
    occ=integer(data$ngrid),
    prev_i=double(data$ngrid),
    prev_u=double(data$ngrid),
    logLik=double(data$ngrid),
    NAOK=TRUE
  ) -> ret
  tibble(
    unit=data$unit,
    time=data$time,
    prev_i=if_else(ret$occ>0,ret$prev_i/ret$occ,NA_real_),
    prev_u=if_else(ret$occ>0,ret$prev_u/ret$occ,NA_real_),
    occ=ret$occ,
    lambda=ret$lambda,
    gamma=ret$gamma,
    logLik=ret$logLik
  )
}

##' @name Bfilter
##' @rdname bernoulli_filter
##' @details \code{Bfilter} uses an alternative algorithm.
##' @return \code{Bfilter} returns the log likelihood of the furnished data.
##' @export
Bfilter <- function (data, theta) {
  data |>
    filter_order() |>
    group_by(patient) |>
    filter(sum(event=="test")>0) |>
    ungroup() |>
    group_split(patient) |>
    vapply(
      Bfilter_internal,
      double(1L),
      lambda=theta$lambda,
      gamma=theta$gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    )
}

## Probability of the given binary test result
## conditional on S or I status, respectively.
test_prob <- function (result, alpha, beta) {
  if (result == 1L) {
    c(alpha,1-beta)
  } else {
    c(1-alpha,beta)
  }
}

## predicted probability of infection at t2
istat_predict <- function (t1, t2, p, lambda, gamma) {
  s <- lambda+gamma
  a <- exp(-s*(t2-t1))
  peq <- lambda/s
  (1-a)*peq+a*p
}

## filter probability and conditional likelihood
istat_filtr <- function (p, result, alpha, beta) {
  if (is.na(result)) {
    c(p=p,lik=1)
  } else {
    P <- unname(c(1-p,p)*test_prob(result,alpha,beta))
    lik <- unname(sum(P))
    c(p=P[2L]/lik,lik=lik)
  }
}

Bfilter_internal <- function (
  data,
  lambda, gamma, p0, isol_factor, alpha, beta
) {
  data |>
    with({
      B <- istat_filtr(
        p=p0,alpha=alpha,beta=beta,
        result=result[1L]
      )
      p <- B[1L]
      ll <- log(B[2L])
      for (k in seq_len(length(time)-1L)) {
        if (loc[k] > 1L) { # in hospital
          if (isol[k]==1L) { # isolated
            p <- istat_predict(
              p=p,
              t1=time[k],t2=time[k+1L],
              lambda=isol_factor*lambda[loc[k]],
              gamma=gamma[loc[k]]
            )
          } else { # unisolated
            p <- istat_predict(
              p=p,
              t1=time[k],t2=time[k+1L],
              lambda=lambda[loc[k]],
              gamma=gamma[loc[k]]
            )
          }
        } else {
          p <- istat_predict(
            p=p,
            t1=time[k],t2=time[k+1L],
            lambda=lambda[1L],
            gamma=gamma[loc[k]]
          )
        }
        B <- istat_filtr(
          p=p,alpha=alpha,beta=beta,
          result=result[k+1L]
        )
        p <- B[1L]
        ll <- ll+log(B[2L])
      }
      unname(ll)
    })
}

## the following line quiets concerns of
## R CMD check regarding the foreach iterator variables
##' @importFrom utils globalVariables
c("unit","time","rowid","patient","event") |>
  utils::globalVariables()
