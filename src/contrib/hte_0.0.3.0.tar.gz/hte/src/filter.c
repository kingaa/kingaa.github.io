// -*- mode: c++; -*-
#include "hte_internal.h"

void test_prob (int result, double alpha, double beta,
                double *out) {
  if (result==1) {
    out[0] = alpha;		// false positive
    out[1] = 1-beta;		// true positive
  } else {
    out[0] = 1-alpha;		// true negative
    out[1] = beta;		// false negative
  }
}

double prediction (double t1, double t2,
                   double p, double lambda, double gamma) {
  if (t2 > t1) {
    double s = lambda+gamma;
    double a = exp(-s*(t2-t1));
    return (1-a)*lambda/s + a*p;
  } else {
    return p;
  }
}

double filtration (int result, double p,
                   double alpha, double beta, double *ll) {
  if (result != NA_INTEGER) {
    double prob[2], lik;
    test_prob(result,alpha,beta,prob);
    prob[0] *= 1-p;
    prob[1] *= p;
    lik = prob[0]+prob[1];
    p = prob[1]/lik;
    *ll += log(lik);
  }
  return p;
}

void Bernoulli_Filter
(
 const double *alpha,	    // false positive testing rate
 const double *beta,	    // false negative testing rate
 const double *p0,	    // prevalence on admission
 const double *isol_fact,   // effect of isolation on susceptibility
 const int *patno,	    // patient number
 const int *result,	    // test result
 const int *isol,	    // contact isolation status (1 = isolated)
 const int *rowid,	    // row id
 const int *loc,	    // location
 const int *dim,	    // dimension of the dataset
 const double *Lambda,	    // force of infection
 const double *Gamma,	    // recovery rate
 const double *Time,	    // timestamps
 // output:
 int *Occ,       // occupancy
 double *Prev_i, // prevalence among isolated patients
 double *Prev_u, // prevalence among unisolated patients
 double *Loglik	 // log likelihood
 ) {
  int k = 0;
  int pat = patno[0];
  double p = *p0;
  double isf = *isol_fact;
  while (k < dim[0]) {          // loop over rows in the data
    if (pat != patno[k]) {
      pat = patno[k];
      p = *p0;
    }
    int tid = rowid[k]-1;	// zero-based row number
    int locat = loc[k]-1;	// zero-based location number
    int isolat = isol[k];	// isolated?
    if (tid < 0 || tid >= dim[2]) err("rowid mistake!\n");
    if (locat < 0 || locat >= dim[1]) err("location mistake!\n");
    // index into Prev, Lambda, Gamma, Loglik, Time, Occ:
    int i = locat + tid*dim[1];
    int i1 = i+dim[1];
    p = filtration(result[k],p,*alpha,*beta,&Loglik[i]);
    k++;
    if (k < dim[0] && pat == patno[k]) {
      while (tid < rowid[k]-1) {
	if (locat > 0) {	// we are in hospital
	  if (isolat) {		// isolated patients
	    p = prediction(Time[i],Time[i1],p,isf*Lambda[i],Gamma[i]);
	    Prev_i[i] += p;	// CHECK ME!
	  } else {              // unisolated patients
	    p = prediction(Time[i],Time[i1],p,Lambda[i],Gamma[i]);
	    Prev_u[i] += p;	// CHECK ME!
	  }
	  Occ[i]++;
	} else {		// we are out of hospital
	  p = prediction(Time[i],Time[i1],p,Lambda[i],Gamma[i]);
	}
	tid++;
	i = i1;
	i1 += dim[1];
      }
    }
  }
}
