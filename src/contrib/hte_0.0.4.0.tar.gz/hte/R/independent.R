##' Independent infection model
##' 
##' Model under which each patient's trajectory of infection is
##' independent, conditional on the force of infection.
##' 
##' @name independent
##' @rdname independent
##' @include bfilter.R stobfun.R
##' @family independent model
##' @family stateful objective functions
##' @param data patient movement, isolation, and testing data
##' @param params named vector of parameters
##' @param est names of parameters to estimate
##' @example examples/indep.R
NULL

##' @rdname independent
##' @details \code{indep_homog_objfun} is a stateful objective
##' function for the independent model with a global lambda and gamma.
##' @export
indep_homog_objfun <- function (params, data, est = character(0)) {
  ## reformat data & extract unit names
  data |> filter_order() |> Bfilter_setup() -> dat
  stobfun(
    embedding(
      lambda=rep.int("lambda",dat$nunit),
      gamma=rep.int("gamma",dat$nunit),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("lambda","gamma","isol_factor"),
    logit=c("alpha","beta","p0"),
    objfun=nll_indep
  )
}

##' @rdname independent
##' @details \code{indep_unit_spec_objfun} is a stateful objective
##' function for the independent model with unit specific lambda, one
##' gamma for inside the hospital, and one gamma outside the hospital.
##' @export
indep_unit_spec_objfun <- function (params, data, est = character(0)) {
  data |> filter_order() |> Bfilter_setup() -> dat
  lambdas <- paste("lambda",dat$units,sep=".")
  gammas <- c("gamma.out",rep.int("gamma",dat$nunit-1L))
  stobfun(
    embedding(
      lambda=lambdas,
      gamma=gammas,
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c(lambdas,"gamma.out","gamma","isol_factor"),
    logit=c("alpha","beta","p0"),
    objfun=nll_indep
  )
}

## negative log likelihood under the
## independent model
nll_indep <- function (theta, data) {
  lg <- extend_lambda_gamma(
    lambda=theta$lambda,
    gamma=theta$gamma,
    nunit=data$nunit,
    ngrid=data$nunit
  )
  data$data |>
    vapply(
      Bfilter_internal,
      double(1L),
      lambda=theta$lambda,
      gamma=theta$gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    ) |>
    sum() -> ll
  -ll
}
