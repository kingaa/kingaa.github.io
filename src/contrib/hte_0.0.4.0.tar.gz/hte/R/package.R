##' Hospital transmission estimation
##'
##' The \pkg{hte} package ...
##'
##' @name hte-package
##' @aliases hte,package
##' @rdname package
##' @docType package
##' @author Aaron A. King
##' @useDynLib hte, .registration = TRUE, .fixes="HTE_"
##' @import methods
##' 
NULL

.onAttach <- function (...) {
  options(dplyr.summarise.inform=FALSE)
}

pStop <- function (fn, ...) {
  fn <- as.character(fn)
  stop("in ",sQuote(fn[1L]),": ",...,call.=FALSE)
}

pStop_ <- function (...) {
  stop(...,call.=FALSE)
}

pWarn <- function (fn, ...) {
  fn <- as.character(fn)
  warning("in ",sQuote(fn[1L]),": ",...,call.=FALSE)
}

pWarn_ <- function (...) {
  warning(...,call.=FALSE)
}

pMess <- function (fn, ...) {
  fn <- as.character(fn)
  message("NOTE: in ",sQuote(fn[1L]),": ",...)
}

pMess_ <- function (...) {
  message("NOTE: ",...)
}
