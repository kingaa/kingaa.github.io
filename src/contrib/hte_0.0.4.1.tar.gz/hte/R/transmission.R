##' Transmission model
##'
##' Model under which the force of infection in each unit is
##' proportional to the prevalence of infection in that unit.
##' 
##' @name transmission
##' @rdname transmission
##' @family transmission model
##' @family stateful objective functions
##' @include bfilter.R stobfun.R
##' @example examples/transmiss.R
NULL

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @details \code{trans_homog_objfun} is a stateful objective
##' function for the transmission model with a global b and gamma.
##' @export
trans_homog_objfun <- function (params, data, est = character(0)) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  nunit <- length(dat$unitnames)
  stobfun(
    embedding(
      bu=rep.int("bi",nunit-1L),
      bi=rep.int("bu",nunit-1L),
      gamma=rep.int("gamma",nunit),
      lambda=rep.int("gamma",nunit),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("bu","bi","gamma","isol_factor"),
    logit=c("alpha","beta","p0"),
    objfun=nll_fixed_point
  )
}

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @details \code{trans_unit_spec_objfun} is a stateful objective function
##' for the transmission model with unit-specific transmission rates,
##' an out-of-hospital force of infection parameter,
##' and recovery rates that can be different inside and outside of hospital.
##' @export
trans_unit_spec_objfun <- function (params, data, est = character(0)) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  units <- dat$unitnames
  bus <- paste("bu",units[-1L],sep=".")
  bis <- paste("bi",units[-1L],sep=".")
  stobfun(
    embedding(
      bu=bus,
      bi=bis,
      lambda=c("lambda.out",rep.int("gamma",length(units)-1L)),
      gamma=c("gamma.out",rep.int("gamma",length(units)-1L)),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("bu","bi","gamma","gamma.out","lambda.out","isol_factor"),
    logit=c("alpha","beta","p0"),
    objfun=nll_fixed_point
  )
}

##' @importFrom dplyr coalesce
nll_fixed_point <- function (
  theta, data,
  tol = 1e-4, maxit = 10
) {
  nunit <- length(data$unitnames)
  stopifnot(
    `bad bu parameter`=length(theta$bu)==nunit-1L,
    `bad bi parameter`=length(theta$bi)==nunit-1L
  )
  Bu <- c(0,theta$bu)
  Bi <- c(0,theta$bi)
  lambda <- tryCatch(
    extend_vec(theta$lambda,nunit,data$ngrid),
    error = function (e) pStop_("lambda: ",conditionMessage(e))
  )
  gamma <- tryCatch(
    extend_vec(theta$gamma,nunit,data$ngrid),
    error = function (e) pStop_("gamma: ",conditionMessage(e))
  )
  data |>
    Bernoulli_filter_internal(
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    ) -> ff
  lambda <- coalesce(
    Bu*ff$prev_u + Bi*ff$prev_i,
    lambda
  )
  gamma <- ff$gamma
  i <- 0L
  dist <- Inf
  while (dist > tol && i < maxit) {
    data |>
      Bernoulli_filter_internal(
        lambda=lambda,
        gamma=gamma,
        p0=theta$p0,
        alpha=theta$alpha,
        beta=theta$beta,
        isol_factor=theta$isol_factor
      ) -> res
    new_lambda <- Bu*res$prev_u + Bi*res$prev_i
    stopifnot(length(new_lambda)==length(res$lambda))
    dist <- mean(abs(new_lambda-lambda),na.rm=TRUE)
    lambda <- coalesce(new_lambda,lambda)
    i <- i+1L
  }
  if (dist > tol)
    warning("maximum number of iterations reached!")
  -sum(res$logLik)
}
