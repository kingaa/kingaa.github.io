#include "hte_internal.h"
#include <R_ext/Rdynload.h>

static const R_CallMethodDef callMethods[] = {
  {NULL, NULL, 0}
};

void R_init_hte (DllInfo *info) {
  // C functions
  R_RegisterCCallable("hte", "Bernoulli_Filter", (DL_FUNC) &Bernoulli_Filter);
  R_RegisterCCallable("hte", "BFilter", (DL_FUNC) &BFilter);
  // Register routines
  R_registerRoutines(info,NULL,callMethods,NULL,NULL);
  R_useDynamicSymbols(info,TRUE);
}
