library(tidyverse)
library(lubridate)
library(pomp)
library(hte)

set.seed(299012132)

fake_data |>
  arrange(patient,time) -> dat

indep_homog_objfun(
  params=c(
    lambda=0.1,gamma=0.01,p0=0.1,
    isol_factor=0.2,alpha=0.02,beta=0.1
  ),
  est=c("lambda","gamma"),
  data=dat
) -> f

optim(
  par=log(c(0.15,0.015)),
  fn=f,
  control=list(reltol=1e-4)
) -> out
f(out$par)
coef(f)

theta <- coef(f)
indep_unit_spec_objfun(
  params=c(
    lambda=setNames(rep.int(theta["lambda"],6),unique(dat$unit)),
    gamma.out=unname(theta["gamma"]),
    theta[c("p0","gamma","alpha","beta","isol_factor")]
  ),
  est=c("lambda.out","gamma.out"),
  data=dat
) -> h

optim(
  par=log(coef(h)[c("lambda.out","gamma.out")]),
  fn=h,
  control=list(reltol=1e-4)
) -> out
h(out$par)
coef(h)
