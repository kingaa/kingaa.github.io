##' Bernoulli filter
##'
##' Filter the individual patient data with given forces of infection,
##' recovery rates, and test characteristics.
##' 
##' @name Bernoulli_filter
##' @rdname bernoulli_filter
##' @details \code{Bernoulli_filter} runs a Bernoulli filter,
##' updating the expected prevalence.
##' It returns the log likelihood, occupancy, and expected prevalences.
##' @return \code{Bernoulli_filter} returns a \code{\link[tibble]{tibble}}
##' containing the expected prevalences (for both isolated and un-isolated
##' patients), unit occupancy, force of infection, and conditional log
##' likelihood for each unit at each event time.
##' The sum of the log likelihood column (\code{logLik}) is the log
##' likelihood of the data.
##' @include package.R
##' @importFrom dplyr mutate arrange select group_split group_by
##' @importFrom tibble rowid_to_column tibble
##' @importFrom tidyr expand_grid
##' @param data data set
##' @param theta list of parameters
##' @param lambda unit-specific force of infection
##' @param gamma unit-specific recovery rate
##' @example examples/bfilt.R
##' @export
Bernoulli_filter <- function (data, lambda, gamma, theta) {
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  lambda <- tryCatch(
    extend_vec(lambda,length(dat$unitnames),dat$ngrid),
    error = function (e) pStop("Bernoulli_filter","lambda: ",conditionMessage(e))
  )
  gamma <- tryCatch(
    extend_vec(gamma,length(dat$unitnames),dat$ngrid),
    error = function (e) pStop("Bernoulli_filter","gamma: ",conditionMessage(e))
  )
  dat |>
    Bernoulli_filter_internal(
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    )
}

filter_order <- function (data) {
  ## names of all units; "out" must be first
  U <- c("out",setdiff(sort(unique(data$unit)),"out"))
  data |>
    mutate(
      patient=factor(patient),
      unit=factor(unit,levels=U),
      loc=as.integer(unit)
    ) |>
    arrange(time,patient) |>
    rowid_to_column() |>
    arrange(patient,rowid)
}

## Do one-time setup for Bernoulli filtering
## This assumes the data have been ordered using
## 'filter_order'
Bernoulli_filter_setup <- function (data) {
  times <- sort(data$time)
  units <- levels(data$unit)
  grid <- expand_grid(
    time=as.double(times),
    unit=units
  )
  list(
    patno=as.integer(data$patient),
    result=as.integer(data$result),
    isol=as.integer(data$isol),
    rowid=as.integer(data$rowid),
    loc=as.integer(data$loc),
    dim=as.integer(
      c(nrow(data),length(units),length(times))
    ),
    time=grid$time,
    unit=grid$unit,
    ngrid=nrow(grid),
    unitnames=units
  )
}

## Extend the furnished vector into one of the appropriate size.
extend_vec <- function (x, nu, nout = nu) {
  n <- length(x)
  if (n != 1L && n != nu && n != nout)
    pStop("extend_vec","x should have length 1, ",nu,", or ",nout,".")
  if (n != nout)
    x <- rep_len(x,nout)
  x
}

## 'data' is assumed to be pre-processed by 'filter_order'
Bernoulli_filter_internal <- function (
  data, lambda, gamma,
  p0, alpha, beta, isol_factor
) {
  .C(
    "Bernoulli_Filter",
    alpha=as.double(alpha),
    beta=as.double(beta),
    p0=as.double(p0),
    isol_factor=as.double(isol_factor),
    patno=data$patno,
    result=data$result,
    isol=data$isol,
    rowid=data$rowid,
    loc=data$loc,
    dim=data$dim,
    lambda=as.double(lambda),
    gamma=as.double(gamma),
    time=data$time,
    occ=integer(data$ngrid),
    prev_i=double(data$ngrid),
    prev_u=double(data$ngrid),
    logLik=double(data$ngrid),
    NAOK=TRUE
  ) -> ret
  tibble(
    unit=data$unit,
    time=data$time,
    prev_i=if_else(ret$occ>0,ret$prev_i/ret$occ,NA_real_),
    prev_u=if_else(ret$occ>0,ret$prev_u/ret$occ,NA_real_),
    occ=ret$occ,
    lambda=ret$lambda,
    gamma=ret$gamma,
    logLik=ret$logLik
  )
}

##' @name Bfilter
##' @rdname bernoulli_filter
##' @details \code{Bfilter} uses an alternative algorithm.
##' @return \code{Bfilter} returns the log likelihood of the furnished data.
##' @export
Bfilter <- function (data, theta) {
  data |>
    filter_order() |>
    Bfilter_setup() -> dat
  lambda <- tryCatch(
    extend_vec(theta$lambda,dat$nunit),
    error = function (e) pStop("Bfilter","lambda: ",conditionMessage(e))
  )
  gamma <- tryCatch(
    extend_vec(theta$gamma,dat$nunit),
    error = function (e) pStop("Bfilter","gamma: ",conditionMessage(e))
  )
  dat$data |>
    vapply(
      Bfilter_internal,
      double(1L),
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    )
}

Bfilter_setup <- function (data) {
  units <- levels(data$unit)
  data |>
    group_by(patient) |>
    filter(sum(event=="test")>0) |>
    ungroup() |>
    group_split(patient) -> dat
  list(
    data=dat,
    units=units,
    nunit=length(units)
  )
}

Bfilter_internal <- function (
  data,
  lambda, gamma, p0, isol_factor, alpha, beta
) {
  .C(
    "BFilter",
    alpha=as.double(alpha),
    beta=as.double(beta),
    p0=as.double(p0),
    isol_factor=as.double(isol_factor),
    result=data$result,
    isol=data$isol,
    loc=data$loc,
    time=data$time,
    dim=as.integer(nrow(data)),
    lambda=as.double(lambda),
    gamma=as.double(gamma),
    logLik=double(1L),
    NAOK=TRUE
  ) -> ret
  ret$logLik
}

## the following line quiets concerns of
## R CMD check regarding the foreach iterator variables
##' @importFrom utils globalVariables
c("unit","time","rowid","patient","event") |>
  utils::globalVariables()
