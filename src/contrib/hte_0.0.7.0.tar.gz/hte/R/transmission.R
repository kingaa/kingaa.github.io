##' Transmission model
##'
##' Model under which the force of infection in each unit is
##' proportional to the prevalence of infection in that unit.
##'
##' The basic transmission model assumes that the force of infection
##' on an unisolated patient is
##' \deqn{\lambda=b(P_u+aP_i),}{lambda=b*(Pu+a*Pi),}
##' where \eqn{P_u}{Pu}, \eqn{P_i}{Pi} are the prevalences among unisolated
##' and isolated patients, respectively.
##' On an isolated patient, this force of infection is reduced by the factor
##' \code{isol_factor}.
##'
##' @name transmission
##' @rdname transmission
##' @family transmission model
##' @family stateful objective functions
##' @include bfilter.R stobfun.R
##' @example examples/transmiss.R
NULL

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @param tol positive scalar; convergence tolerance (mean difference).
##' @param maxit scalar integer; maximum number of fixed-point iterations.
##' If \code{tol} is not achieved in \code{maxit} or fewer iterations, an error is generated.
##' @details \code{trans_homog_objfun} is a stateful objective
##' function for the transmission model with global a, b, and gamma.
##' @export
trans_homog_objfun <- function (
  params, data, est = character(0),
  tol = 1e-4, maxit = 10
) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  nunit <- length(dat$unitnames)
  stobfun(
    embedding(
      a=rep.int("a",nunit-1L),
      b=rep.int("b",nunit-1L),
      gamma=rep.int("gamma",nunit),
      lambda=rep.int("gamma",nunit),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c("a","b","gamma","isol_factor"),
    logit=c("alpha","beta","p0"),
    tol=tol,
    maxit=maxit,
    objfun=nll_fixed_point
  )
}

##' @rdname transmission
##' @inheritParams indep_homog_objfun
##' @details \code{trans_unit_spec_objfun} is a stateful objective function
##' for the transmission model with unit-specific transmission rates,
##' an out-of-hospital force of infection parameter,
##' and recovery rates that can be different inside and outside of hospital.
##' @export
trans_unit_spec_objfun <- function (
  params, data, est = character(0),
  tol = 1e-4, maxit = 10
  ) {
  ## reformat data & extract unit names
  data |>
    filter_order() |>
    Bernoulli_filter_setup() -> dat
  units <- dat$unitnames
  as <- paste("a",units[-1L],sep=".")
  bs <- paste("b",units[-1L],sep=".")
  stobfun(
    embedding(
      a=as,
      b=bs,
      lambda=c("lambda.out",rep.int("gamma",length(units)-1L)),
      gamma=c("gamma.out",rep.int("gamma",length(units)-1L)),
      p0="p0",
      alpha="alpha",
      beta="beta",
      isol_factor="isol_factor"
    ),
    params=params,
    data=dat,
    est=est,
    log=c(as,bs,"gamma","gamma.out","lambda.out","isol_factor"),
    logit=c("alpha","beta","p0"),
    tol=tol,
    maxit=maxit,
    objfun=nll_fixed_point
  )
}

##' @importFrom dplyr coalesce
nll_fixed_point <- function (
  theta, data,
  tol = 1e-4, maxit = 10
) {
  nunit <- length(data$unitnames)
  stopifnot(
    `bad a parameter`=length(theta$a)==nunit-1L,
    `bad b parameter`=length(theta$b)==nunit-1L
  )
  A <- c(0,theta$a)
  B <- c(0,theta$b)
  lambda <- tryCatch(
    extend_vec(theta$lambda,nunit,data$dim[4L]),
    error = function (e) pStop_("lambda: ",conditionMessage(e))
  )
  gamma <- tryCatch(
    extend_vec(theta$gamma,nunit,data$dim[4L]),
    error = function (e) pStop_("gamma: ",conditionMessage(e))
  )
  data |>
    Bernoulli_filter_internal(
      lambda=lambda,
      gamma=gamma,
      p0=theta$p0,
      alpha=theta$alpha,
      beta=theta$beta,
      isol_factor=theta$isol_factor
    ) -> ff
  lambda <- coalesce(
    B*(ff$prev_u + A*ff$prev_i),
    lambda
  )
  gamma <- ff$gamma
  i <- 0L
  dist <- Inf
  while (dist > tol && i < maxit) {
    data |>
      Bernoulli_filter_internal(
        lambda=lambda,
        gamma=gamma,
        p0=theta$p0,
        alpha=theta$alpha,
        beta=theta$beta,
        isol_factor=theta$isol_factor
      ) -> ff
    new_lambda <- B*(ff$prev_u + A*ff$prev_i)
    stopifnot(length(new_lambda)==length(ff$lambda))
    dist <- mean(abs(new_lambda-lambda),na.rm=TRUE)
    lambda <- coalesce(new_lambda,lambda)
    i <- i+1L
  }
  if (dist > tol)
    pWarn("nll_fixed_point","maximum number of iterations reached!")
  -sum(ff$logLik)
}
