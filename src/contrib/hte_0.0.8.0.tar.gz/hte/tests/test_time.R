library(tidyverse)
library(hte)

## Isolation model using old codes

testProbabilities <- function (result, alpha, beta) {
  if (result==1) {
    c(alpha,1-beta)
  } else {
    c(1-alpha,beta)
  }
}

prediction <- function (t_1, t_2, p, lambda, gamma) {
  a <- exp(-(lambda+gamma)*(t_2-t_1))
  (1-a)*(lambda/(lambda+gamma))+a*p
}

filtration <- function (result, p, alpha, beta) {
  if (is.na(result)) {
    c(p=p,lik=1)
  } else {
    P <- c(1-p,p)*testProbabilities(result,alpha,beta)
    lik <- sum(P)
    c(p=P[2]/lik,lik=lik)
  }
}

L_i <- function (data, lambda, gamma, alpha, beta, p0, isol_factor) {
  k <- 1L
  ll <- 0
  p <- p0
  while (k < nrow(data)) {
    loc <- data$loc[k]
    isol <- data$isol[k]
    B <- filtration(data$result[k],p,alpha,beta)
    p <- B[1L]
    ll <- ll+log(B[2L])
    p <- prediction(
      t_1=data$time[k],
      t_2=data$time[k+1L],
      p=p,
      lambda=if (isol) isol_factor*lambda[loc] else lambda[loc],
      gamma=gamma
    )
    k <- k+1
  }
  B <- filtration(data$result[k],p,alpha,beta)
  ll <- ll+log(B[2L])
  ll
}

nll_homog <- function (theta, data) {
  -sum(
    sapply(
      data,
      L_i,
      lambda=rep(theta["lambda"],nunits),
      gamma=theta["gamma"],
      alpha=theta["alpha"],
      beta=theta["beta"],
      p0=theta["p0"],
      isol_factor = theta["isol_factor"]
    )
  )
}

ptrans1 <- function (theta) {
  c(
    log(theta[c("lambda","gamma","isol_factor")]),
    qlogis(theta[c("alpha","beta","p0")])
  )
}

itrans1 <- function (theta) {
  c(
    exp(theta[c("lambda","gamma","isol_factor")]),
    plogis(theta[c("alpha","beta","p0")])
  )
}

fake_data |>
  filter(time <= 100) |>
  arrange(patient,time) -> dat

nunits <- length(unique(dat$unit))

dat |>
  mutate(
    loc=match(unit,sort(unique(unit))),
    isol=if_else(unit=="out",0,isol)
  ) |>
  arrange(patient,time) |>
  group_split(patient) -> patient_history

theta <- c(lambda=0.01,gamma=0.01,isol_factor=0.1,alpha=0.02,beta=0.1,p0=0.07)

tik <- Sys.time()
optim(
  par=ptrans1(theta),
  fn=function (theta) {
    nll_homog(itrans1(theta),patient_history)
  },
  method="BFGS",
  control=list(trace=4,reltol=1e-4)
) -> out1
tak <- Sys.time()
etime1 <- tak - tik
etime1

out1$value
itrans1(out1$par)

## Isolation model using new codes (hte package)

indep_homog_objfun(
  params=theta,
  est=c("lambda","gamma","isol_factor","alpha","beta","p0"),
  data=dat
) -> f

nll_homog(theta,data=patient_history)
f(ptrans1(theta))

tik <- Sys.time()
optim(
  par=ptrans1(theta),
  fn=f,
  method="BFGS",
  control=list(trace=4,reltol=1e-4)
) -> out2
tak <- Sys.time()
etime2 <- tak - tik
etime2

f(out2$par)
coef(f)

stopifnot(
  all(out1$counts==out2$counts,na.rm=TRUE),
  all.equal(out1$value,out2$value,tolerance=1e-4),
  all.equal(out1$par,out2$par,tolerance=1e-4),
  all.equal(itrans1(out1$par),coef(f),tolerance=1e-4)
)

as.numeric(etime2,units="secs")/as.numeric(etime1,units="secs")
