library(tidyverse)
library(hte)

set.seed(339613584)

fake_data |>
  ## filter out tests prior to day 250
  filter(
    event!="test" | time < 250,
    time < 1000
  ) |>
  select(-infected) |>
  arrange(patient,time) -> dat

trans_homog_objfun(
  params=c(
    a=1,b=0.1,gamma=0.01,p0=0.1,lambda.out=0.01,
    isol_factor=0.2,alpha=0.02,beta=0.1
  ),
  est=c("a","b"),
  data=dat
) -> f
f(log(c(0.05,0.4)))
coef(f)

optim(
  par=log(c(0.5,0.4)),
  fn=f,
  method="BFGS",
  control=list(reltol=1e-4)
) -> out
f(out$par)
coef(f)

try({
  trans_homog_objfun(
    params=c(
      a=1,b=0.1,gamma=0.01,p0=0.1,lambda.out=0.01,
      isol_factor=0.2,alpha=0.02,beta=0.1
    ),
    maxit=1,
    data=dat
  ) -> f
  f()
})

try({
  trans_homog_objfun(
    params=c(
      a=1,b=0.1,gamma=0.01,p0=0.1,
      isol_factor=0.2,alpha=0.02,beta=0.1
    ),
    data=dat
  ) -> f
  f()
})
