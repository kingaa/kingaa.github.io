// -*- mode: c++; -*-
#include "hte_internal.h"

SEXP Bernoulli_Filter_Wrapper
(SEXP Alpha, SEXP Beta, SEXP P0, SEXP Isol_Factor,
 SEXP Patno, SEXP Result, SEXP Isol, SEXP Rowid, SEXP Loc,
 SEXP Dim,
 SEXP Lambda, SEXP Gamma,
 SEXP Unit, SEXP Time
 ) {
  SEXP Occ, Prev_i, Prev_u, LogLik;
  SEXP ans, nm;
  int ngrid = INTEGER(Dim)[3];
  PROTECT(Occ = NEW_INTEGER(ngrid));
  PROTECT(Prev_i = NEW_NUMERIC(ngrid));
  PROTECT(Prev_u = NEW_NUMERIC(ngrid));
  PROTECT(LogLik = NEW_NUMERIC(ngrid));
  int *occ = INTEGER(Occ);
  double *prev_i = REAL(Prev_i);
  double *prev_u = REAL(Prev_u);
  double *logLik = REAL(LogLik);
  int k;
  for (k = 0; k < ngrid; k++) {
    occ[k] = 0;
    prev_i[k] = prev_u[k] = 0;
    logLik[k] = 0;
  }
  Bernoulli_Filter(REAL(Alpha),REAL(Beta),REAL(P0),REAL(Isol_Factor),
		   INTEGER(Patno),INTEGER(Result),INTEGER(Isol),
		   INTEGER(Rowid),INTEGER(Loc),INTEGER(Dim),
		   REAL(Lambda),REAL(Gamma),REAL(Time),
		   INTEGER(Occ),REAL(Prev_i),REAL(Prev_u),REAL(LogLik));
  PROTECT(ans = NEW_LIST(8));
  PROTECT(nm = NEW_CHARACTER(8));
  SET_ELEMENT(ans,0,Unit); SET_STRING_ELT(nm,0,mkChar("unit"));
  SET_ELEMENT(ans,1,Time); SET_STRING_ELT(nm,1,mkChar("time"));
  SET_ELEMENT(ans,2,Prev_i); SET_STRING_ELT(nm,2,mkChar("prev_i"));
  SET_ELEMENT(ans,3,Prev_u); SET_STRING_ELT(nm,3,mkChar("prev_u"));
  SET_ELEMENT(ans,4,Occ); SET_STRING_ELT(nm,4,mkChar("occ"));
  SET_ELEMENT(ans,5,Lambda); SET_STRING_ELT(nm,5,mkChar("lambda"));
  SET_ELEMENT(ans,6,Gamma); SET_STRING_ELT(nm,6,mkChar("gamma"));
  SET_ELEMENT(ans,7,LogLik); SET_STRING_ELT(nm,7,mkChar("logLik"));
  SET_NAMES(ans,nm);
  UNPROTECT(6);
  return ans;
}

static inline double prediction
(double t1, double t2, double p, double lambda, double gamma)
{
  if (t2 > t1) {
    double s = lambda+gamma;
    double a = exp(-s*(t2-t1));
    return (1-a)*lambda/s + a*p;
  } else {
    return p;
  }
}

static inline void test_prob
(int result, double alpha, double beta, double *out)
{
  if (result==1) {
    out[0] = alpha;		// false positive
    out[1] = 1-beta;		// true positive
  } else {
    out[0] = 1-alpha;		// true negative
    out[1] = beta;		// false negative
  }
}

static inline double filtration
(int result, double p, double alpha, double beta, double *ll)
{
  if (result != NA_INTEGER) {
    double prob[2], lik;
    test_prob(result,alpha,beta,prob);
    prob[0] *= 1-p;
    prob[1] *= p;
    lik = prob[0]+prob[1];
    p = prob[1]/lik;
    *ll += log(lik);
  }
  return p;
}

//! This is the main Bernoulli filter.
//! The data enter through the 'patno', 'result', 'isol', 'rowid', and 'loc'
//! arguments. Each of these are of the same length (the number of events).
//! It is assumed that the data have been sorted into blocks, one block per
//! patient.
//! The input arguments 'Lambda', 'Gamma', 'Time', however, are pointers to
//! matrices, with one row per location (unit) and one column per event.
//! The output arguments ('Occ', 'Prev_i', 'Prev_u', 'LogLik') are similarly
//! matrices of this form.
//! It is assumed that, prior to the call, these have been zeroed.
//! It is assumed that location 0 corresponds to outside the hospital.
void Bernoulli_Filter
(
 // input:
 const double *alpha,	    // false positive testing rate
 const double *beta,	    // false negative testing rate
 const double *p0,	    // prevalence on admission
 const double *isol_fact,   // effect of isolation on susceptibility
 const int *patno,	    // patient number
 const int *result,	    // test result
 const int *isol,	    // contact isolation status (1 = isolated)
 const int *rowid,	    // row id
 const int *loc,	    // location
 const int *dim,	    // dimension of the dataset
 const double *Lambda,	    // force of infection
 const double *Gamma,	    // recovery rate
 const double *Time,	    // timestamps
 // output:
 int *Occ,       // occupancy
 double *Prev_i, // prevalence among isolated patients
 double *Prev_u, // prevalence among unisolated patients
 double *Loglik	 // log likelihood
 ) {
  int k = 0;		// pointer to line in the patient-history data
  int pat = patno[0];	// patient number
  double p = *p0;	// probability of infection
  double isf = *isol_fact;
  while (k < dim[0]) {          // loop over events
    if (pat != patno[k]) {	// beginning of a new patient block
      pat = patno[k];
      p = *p0;
    }
    int event = rowid[k]-1;	// zero-based column number
    int locat = loc[k]-1;	// zero-based row number
    int isolat = isol[k];	// is the patient isolated?
    if (event < 0 || event >= dim[2])
      err("in '%s': rowid mistake!\n",__func__); // #nocov
    if (locat < 0 || locat >= dim[1])
      err("in '%s': location mistake!\n",__func__); // #nocov
    // indices into Prev, Lambda, Gamma, Loglik, Time, Occ:
    int i = locat + event*dim[1]; // current unit & event
    int i1 = i+dim[1];		  // next event, same unit
    // assimilate new test result:
    p = filtration(result[k],p,*alpha,*beta,&Loglik[i]);
    k++;		    // advance to next line in patient history
    if (k < dim[0] && pat == patno[k]) {
      if (locat > 0) {	// we are in hospital
	// step through events to next event that involves this patient:
	while (event < rowid[k]-1) {
	  if (isolat) {		// isolated patients
	    Prev_i[i] += p;	// CHECK ME!
	    // predict status at next timepoint:
	    p = prediction(Time[i],Time[i1],p,isf*Lambda[i],Gamma[i]);
	  } else {              // unisolated patients
	    Prev_u[i] += p;	// CHECK ME!
	    // predict status at next timepoint:
	    p = prediction(Time[i],Time[i1],p,Lambda[i],Gamma[i]);
	  }
	  Occ[i]++;	// increment occupancy
	  event++;
	  i = i1;
	  i1 += dim[1];
	}
      } else {		// we are out of hospital
	// prevalence and occupancy are not tracked for location 0
	// predict status at next timepoint:
	event = rowid[k]-1;
	i1 = event*dim[1];
	p = prediction(Time[i],Time[i1],p,Lambda[i],Gamma[i]);
      }
    }
  }
  // compute prevalence
  for (k = 0; k < dim[3]; k++) {
    if (Occ[k] > 0) {
      Prev_i[k] /= Occ[k];	// frequency-dependence!
      Prev_u[k] /= Occ[k];	// frequency-dependence!
    } else {
      Prev_i[k] = Prev_u[k] = R_NaReal;
    }
  }
}

void BFilter
(
 const double *alpha,	    // false positive testing rate
 const double *beta,	    // false negative testing rate
 const double *p0,	    // prevalence on admission
 const double *isol_fact,   // effect of isolation on susceptibility
 const int *result,	    // test result
 const int *isol,	    // contact isolation status (1 = isolated)
 const int *loc,	    // location
 const double *time,	    // time
 const int *dim,	    // dimension of the data
 const double *lambda,	    // force of infection
 const double *gamma,	    // recovery rate
 // output:
 double *logLik		    // log likelihood
 ) {
  int k = 0;
  double p = *p0;
  double isf = *isol_fact;
  *logLik = 0;
  p = filtration(result[0],p,*alpha,*beta,logLik);
  k++;
  while (k < *dim) {
    int locat = loc[k-1]-1;	// zero-based location number
    int isolat = isol[k-1];	// isolated?
    if (isolat && locat > 0) { // isolated patient
      p = prediction(time[k-1],time[k],p,isf*lambda[locat],gamma[locat]);
    } else {			// unisolated patient
      p = prediction(time[k-1],time[k],p,lambda[locat],gamma[locat]);
    }
    p = filtration(result[k],p,*alpha,*beta,logLik);
    k++;
  }
}
