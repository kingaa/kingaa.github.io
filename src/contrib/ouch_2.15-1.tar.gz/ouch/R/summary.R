#' Summary methods
#'
#' @name summary
#' @rdname summary
#' @include ouchtree.R brown.R hansen.R
#' @param object fitted model object.
#' @param ... additional arguments, ignored.
#'
NULL
