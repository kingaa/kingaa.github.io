#' Summary methods
#'
#' @name summary
#' @rdname summary
#' @family methods
#' @param object fitted model object.
#' @param ... additional arguments, ignored.
#'
NULL
