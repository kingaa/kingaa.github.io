#' \pkg{ouch} summary methods
#'
#' @name summary
#' @rdname summary
#' @family methods for ouch trees
#' @param object fitted model object.
#' @param ... additional arguments, ignored.
#'
NULL
