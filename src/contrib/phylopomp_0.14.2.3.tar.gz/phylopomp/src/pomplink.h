#ifndef _PHYLOPOMP_POMPLINK_H_
#define _PHYLOPOMP_POMPLINK_H_

#include <pomp.h>
#include <R_ext/Rdynload.h>

extern get_userdata_t *get_userdata;
extern get_userdata_int_t *get_userdata_int;
extern get_userdata_double_t *get_userdata_double;

#endif
