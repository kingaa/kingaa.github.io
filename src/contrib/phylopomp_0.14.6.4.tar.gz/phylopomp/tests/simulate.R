library(phylopomp)
simulate()
try(simulate(22))
