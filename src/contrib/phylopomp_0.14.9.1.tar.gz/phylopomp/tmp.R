library(tidyverse)
library(phylopomp)
library(doFuture)
library(iterators)

theta <- list(lambda=3,mu=2,psi=1,time=5,n0=10)

theta |>
  with(
    simulate("LBDP",lambda=lambda,psi=psi,mu=mu,time=time,n0=n0)
  ) -> x

x |> plot()

x |> lineages() |> plot()

theta |>
  with(
    expand_grid(
      lambda=lambda,
      mu=seq(0.3*mu,3*mu,length=50),
      psi=psi,
      time=time,
      n0=n0
    )
  ) -> params

plan(multicore)

foreach (p=iter(params,"row"),.combine=bind_rows) %dofuture%
  {
    p |>
      with(
        lbdp_exact(x,lambda=lambda,mu=mu,psi=psi,n0=n0)
      ) -> ll
    p |> bind_cols(logLik=ll)
  } -> dat

dat |>
  ggplot(aes(x=mu,y=logLik))+
  geom_point()+
  geom_line()+
  geom_vline(xintercept=theta$mu)+
  lims(y=c(max(dat$logLik)-10,NA))+
  labs(x=expression(mu))+
  theme_bw(base_size=20)
  

theta |>
  with(
    expand_grid(
      lambda=lambda,
      mu=seq(0.3*mu,3*mu,length=20),
      psi=seq(0.3*psi,3*psi,length=20),
      time=time,
      n0=n0
    )
  ) -> params

plan(multicore)

foreach (p=iter(params,"row"),.combine=bind_rows) %dofuture%
  {
    p |>
      with(
        lbdp_exact(x,lambda=lambda,mu=mu,psi=psi,n0=n0)
      ) -> ll
    p |> bind_cols(logLik=ll)
  } -> dat

dat |>
  ggplot(aes(x=mu,y=psi,z=logLik,fill=logLik))+
  geom_tile(color=NA)+
  geom_contour(binwidth=2)+
  geom_vline(xintercept=theta$mu)+
  geom_hline(yintercept=theta$psi)+
  labs(x=expression(mu),y=expression(psi))+
  theme_bw(base_size=20)
  

simulate("SEIRS",time=10,omega=2) -> x

x |> plot(obscure=FALSE)
x |> lineages() |> plot()
x |> gendat() |> names()

x |>
  gendat() |>
  _[c("nodetype","deme","child","ancestor")] |>
  bind_cols() |>
  mutate(name=seq_along(deme)-1)
