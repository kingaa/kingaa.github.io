library(phylopomp)
try(simulate("billyjoe"))
try(simulate(22))
simulate()
