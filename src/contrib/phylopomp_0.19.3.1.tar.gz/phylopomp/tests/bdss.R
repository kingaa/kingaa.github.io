png(filename="bdss-%02d.png",res=100)

options(digits=3)
suppressPackageStartupMessages({
  library(ggplot2)
  library(phylopomp)
})
set.seed(20260604)

x <- runBDSS(time=5)
stopifnot(
  attr(x, "model") == "BDSS",
  inherits(x, "gpsim")
)
y <- continueBDSS(x, time=6)
plot_grid(
  plot(x)+expand_limits(x=6),
  plot(y)+geom_vline(xintercept=5),
  y |>
    curtail(time=5) |>
    plot()+expand_limits(x=6),
  ncol=1
)

simulate(
  "BDSS",
  time=3,
  lambda_nn = 2,
  lambda_ns = 0,
  lambda_sn = 0,
  lambda_ss = 3,
  mu = 0.5,
  chi = 0.5,
  pop = 15,
  N0 = 10,
  S0 = 5
) |> freeze(445178631) |>
  plot(prune=FALSE,obscure=FALSE)

y |> yaml() -> yaml_out
stopifnot(
  inherits(yaml_out, "gpyaml"),
  gregexpr("lambda",yaml_out) |> regmatches(yaml_out,m=_) |> lengths()==4,
  gregexpr("pocket",yaml_out) |> regmatches(yaml_out,m=_) |> lengths()==212
)

dev.off()
