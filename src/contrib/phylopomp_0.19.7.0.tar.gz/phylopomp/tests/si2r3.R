library(tidyverse)
library(phylopomp)

replicate(
  n=100,
  runSIRS(
    time=5,
    Beta=4,gamma=1,chi=1,psi=0,omega=1,pop=1000,
    S0=0.95,I0=0.05,R0=0
  )
) -> sirs

sirs |> lapply(plot)

replicate(
  n=100,
  runSI2R(
    time=5,
    Beta=4,gamma=1,chi=1,omega=1,pop=1000,
    S0=0.95,IL0=0.05,IH0=0,R0=0,
    kappa=0,etaL=0,etaH=0
  )
) -> si2rs

si2rs |> lapply(plot)

tibble(
  sir=sirs |> sapply(getInfo,nsample=TRUE) |> unlist(),
  si2r=si2rs |> sapply(getInfo,nsample=TRUE) |> unlist()
) -> nsample
t.test(x=nsample$sir,y=nsample$si2r)

tibble(
  sir=sirs |> sapply(getInfo,nroot=TRUE) |> unlist(),
  si2r=si2rs |> sapply(getInfo,nroot=TRUE) |> unlist()
) -> nroot
t.test(x=nroot$sir,y=nroot$si2r)

  
