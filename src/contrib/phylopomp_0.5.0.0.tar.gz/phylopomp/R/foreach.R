##' @importFrom foreach foreach %dopar% registerDoSEQ
##' @include package.R
##' @keywords internal
##' @docType import
##' @export
foreach::foreach
##' @export
foreach::'%dopar%'
##' @export
foreach::registerDoSEQ
