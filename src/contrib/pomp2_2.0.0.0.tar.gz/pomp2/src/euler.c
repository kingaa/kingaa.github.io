// dear emacs, please treat this as -*- C++ -*-

#include <R.h>
#include <Rmath.h>
#include <Rdefines.h>
#include <Rinternals.h>
#include <R_ext/Constants.h>
#include <string.h>

#include "pomp_internal.h"

static R_INLINE SEXP add_args (SEXP args, SEXP Snames, SEXP Pnames, SEXP Cnames)
{
  int nprotect = 0;
  SEXP var;
  int v;

  // we construct the call from end to beginning
  // delta.t, covariates, parameter, states, then time

  // 'delta.t'
  PROTECT(var = NEW_NUMERIC(1)); nprotect++;
  PROTECT(args = LCONS(var,args)); nprotect++;
  SET_TAG(args,install("delta.t"));

  // Covariates
  for (v = LENGTH(Cnames)-1; v >= 0; v--) {
    PROTECT(var = NEW_NUMERIC(1)); nprotect++;
    PROTECT(args = LCONS(var,args)); nprotect++;
    SET_TAG(args,install(CHAR(STRING_ELT(Cnames,v))));
  }

  // Parameters
  for (v = LENGTH(Pnames)-1; v >= 0; v--) {
    PROTECT(var = NEW_NUMERIC(1)); nprotect++;
    PROTECT(args = LCONS(var,args)); nprotect++;
    SET_TAG(args,install(CHAR(STRING_ELT(Pnames,v))));
  }

  // Latent state variables
  for (v = LENGTH(Snames)-1; v >= 0; v--) {
    PROTECT(var = NEW_NUMERIC(1)); nprotect++;
    PROTECT(args = LCONS(var,args)); nprotect++;
    SET_TAG(args,install(CHAR(STRING_ELT(Snames,v))));
  }

  // Time
  PROTECT(var = NEW_NUMERIC(1)); nprotect++;
  PROTECT(args = LCONS(var,args)); nprotect++;
  SET_TAG(args,install("t"));

  UNPROTECT(nprotect);
  return args;

}

static R_INLINE SEXP eval_call (
    SEXP fn, SEXP args,
    double *t, double *dt,
    double *x, int nvar,
    double *p, int npar,
    double *c, int ncov)
{

  SEXP var = args, ans;
  int v;

  *(REAL(CAR(var))) = *t; var = CDR(var);
  for (v = 0; v < nvar; v++, x++, var=CDR(var)) *(REAL(CAR(var))) = *x;
  for (v = 0; v < npar; v++, p++, var=CDR(var)) *(REAL(CAR(var))) = *p;
  for (v = 0; v < ncov; v++, c++, var=CDR(var)) *(REAL(CAR(var))) = *c;
  *(REAL(CAR(var))) = *dt; var = CDR(var);

  PROTECT(ans = eval(LCONS(fn,args),CLOENV(fn)));

  UNPROTECT(1);
  return ans;

}

static R_INLINE SEXP ret_array (int n, int nreps, int ntimes, SEXP names)
{
  int dim[3] = {n, nreps, ntimes};
  const char *dimnm[3] = {"variable", "rep", "time"};
  SEXP Y;

  PROTECT(Y = makearray(3,dim));
  setrownames(Y,names,3);
  fixdimnames(Y,dimnm,3);

  UNPROTECT(1);
  return Y;

}

SEXP euler_model_simulator (SEXP func, SEXP xstart, SEXP times, SEXP params,
  double deltat, rprocmode method, SEXP zeronames, SEXP covar, SEXP args, SEXP gnsi)
{
  int nprotect = 0;
  pompfunmode mode = undef;
  int nvars, npars, nreps, ntimes, nzeros, ncovars;
  double *cov;
  SEXP cvec, X, fn;

  if (deltat <= 0) errorcall(R_NilValue,"'delta.t' should be a positive number."); // #nocov

  int *dim;
  dim = INTEGER(GET_DIM(xstart)); nvars = dim[0]; nreps = dim[1];
  dim = INTEGER(GET_DIM(params)); npars = dim[0];
  ntimes = LENGTH(times);

  SEXP Snames, Pnames, Cnames;
  PROTECT(Snames = GET_ROWNAMES(GET_DIMNAMES(xstart))); nprotect++;
  PROTECT(Pnames = GET_ROWNAMES(GET_DIMNAMES(params))); nprotect++;
  PROTECT(Cnames = get_covariate_names(covar)); nprotect++;

  // set up the covariate table
  lookup_table_t covariate_table = make_covariate_table(covar,&ncovars);
  PROTECT(cvec = NEW_NUMERIC(ncovars)); nprotect++;
  cov = REAL(cvec);

  // indices of accumulator variables
  nzeros = LENGTH(zeronames);
  int *zidx = INTEGER(PROTECT(matchnames(Snames,zeronames,"state variables"))); nprotect++;

  // extract user function
  PROTECT(fn = pomp_fun_handler(func,gnsi,&mode,Snames,Pnames,NA_STRING,Cnames)); nprotect++;

  // array to hold results
  PROTECT(X = ret_array(nvars,nreps,ntimes,Snames)); nprotect++;

  // copy the start values into the result array
  memcpy(REAL(X),REAL(xstart),nvars*nreps*sizeof(double));

  // set up

  int *pidx = 0, *sidx = 0, *cidx = 0;
  pomp_onestep_sim *ff = NULL;

  switch (mode) {

  case Rfun: {

    // construct list of all arguments
    PROTECT(args = add_args(args,Snames,Pnames,Cnames)); nprotect++;

  }

    break;

  case native: case regNative: {

    // construct state, parameter, covariate indices
    sidx = INTEGER(GET_SLOT(func,install("stateindex")));
    pidx = INTEGER(GET_SLOT(func,install("paramindex")));
    cidx = INTEGER(GET_SLOT(func,install("covarindex")));

    *((void **) (&ff)) = R_ExternalPtrAddr(fn);

    set_pomp_userdata(args);
    GetRNGstate();

  }

    break;

  default:

    errorcall(R_NilValue,"unrecognized 'mode' %d",mode); // # nocov

  }

  // main computation loop
  int step;
  double *xs, *xt, *time, t;
  for (step = 1, xs = REAL(X), xt = xs+nvars*nreps, time = REAL(times), t = time[0];
    step < ntimes;
    step++, xs = xt, xt += nvars*nreps) {

    double dt;
    int *posn = NULL;
    int nstep = 0;
    int i, j, k;

    R_CheckUserInterrupt();

    if (t > time[step]) errorcall(R_NilValue,"'times' must be an increasing sequence.");  // #nocov

    memcpy(xt,xs,nreps*nvars*sizeof(double));

    // set accumulator variables to zero
    for (j = 0; j < nreps; j++)
      for (i = 0; i < nzeros; i++)
        xt[zidx[i]+nvars*j] = 0.0;

    // determine size and number of time-steps
    switch (method) {
    case onestep: default:	// one step
      dt = time[step]-t;
      nstep = (dt > 0) ? 1 : 0;
      break;
    case discrete:			// fixed step
      dt = deltat;
      nstep = num_map_steps(t,time[step],dt);
      break;
    case euler:			// Euler method
      dt = deltat;
      nstep = num_euler_steps(t,time[step],&dt);
      break;
    }

    // loop over individual steps
    for (k = 0; k < nstep; k++) {

      // interpolate the covar functions for the covariates
      table_lookup(&covariate_table,t,cov);

      // loop over replicates
      double *ap, *pm, *xm, *ps = REAL(params);

      for (j = 0, pm = ps, xm = xt; j < nreps; j++, pm += npars, xm += nvars) {

        switch (mode) {

        case Rfun: {

          SEXP ans, nm;

          if (j == 0 && k == 0) {

            PROTECT(ans = eval_call(fn,args,&t,&dt,xm,nvars,pm,npars,cov,ncovars)); nprotect++;

            PROTECT(nm = GET_NAMES(ans)); nprotect++;
            if (invalid_names(nm))
              errorcall(R_NilValue,"'rprocess' must return a named numeric vector.");
            posn = INTEGER(PROTECT(matchnames(Snames,nm,"state variables"))); nprotect++;

            ap = REAL(AS_NUMERIC(ans));

            for (i = 0; i < nvars; i++) xm[posn[i]] = ap[i];

          } else {

            PROTECT(ans = eval_call(fn,args,&t,&dt,xm,nvars,pm,npars,cov,ncovars));
            ap = REAL(AS_NUMERIC(ans));
            for (i = 0; i < nvars; i++) xm[posn[i]] = ap[i];
            UNPROTECT(1);

          }

        }

          break;

        case native: case regNative: {

          (*ff)(xm,pm,sidx,pidx,cidx,cov,t,dt);

        }

          break;

        default:

          errorcall(R_NilValue,"unrecognized 'mode' %d",mode); // # nocov

        }

      }

      t += dt;

      if ((method == euler) && (k == nstep-2)) { // penultimate step
        dt = time[step]-t;
        t = time[step]-dt;
      }

    }

  }

  // clean up
  switch (mode) {

  case native: case regNative: {
    PutRNGstate();
    unset_pomp_userdata();

  }

    break;

  case Rfun: default:

    break;

  }

  UNPROTECT(nprotect);
  return X;

}

int num_euler_steps (double t1, double t2, double *dt) {
  double tol = sqrt(DOUBLE_EPS);
  int nstep;
  // nstep will be the number of Euler steps to take in going from t1 to t2.
  // note also that the stepsize changes.
  // this choice is meant to be conservative
  // (i.e., so that the actual dt does not exceed the specified dt
  // by more than the relative tolerance 'tol')
  // and to counteract roundoff error.
  // It seems to work well, but is not guaranteed:
  // suggestions would be appreciated.

  if (t1 >= t2) {
    *dt = 0.0;
    nstep = 0;
  } else if (t1+*dt >= t2) {
    *dt = t2-t1;
    nstep = 1;
  } else {
    nstep = (int) ceil((t2-t1)/(*dt)/(1+tol));
    *dt = (t2-t1)/((double) nstep);
  }
  return nstep;
}

int num_map_steps (double t1, double t2, double dt) {
  double tol = sqrt(DOUBLE_EPS);
  int nstep;
  // nstep will be the number of discrete-time steps to take in going from t1 to t2.
  nstep = (int) floor((t2-t1)/dt/(1-tol));
  return (nstep > 0) ? nstep : 0;
}
