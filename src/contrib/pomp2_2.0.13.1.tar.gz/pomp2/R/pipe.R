##' @importFrom magrittr %>%
##' @docType import
##' @export
magrittr::`%>%`
