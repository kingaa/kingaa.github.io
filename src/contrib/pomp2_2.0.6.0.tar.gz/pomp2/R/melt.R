##' @importFrom reshape2 melt
##' @docType import
##' @export
reshape2::melt
