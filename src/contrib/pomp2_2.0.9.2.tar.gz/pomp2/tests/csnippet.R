library(pomp2)

Csnippet("x = x;") -> cs
as(cs,"character")
as.character(cs)
print(cs)
show(cs)
