library(pompExamples)
pompExample("lavine2013")

freeze(plot(simulate(lavine2013)),seed=1891542367L)

pf <- freeze(pfilter(lavine2013,Np=1000),seed=1863695913L)
print(logLik(pf))
