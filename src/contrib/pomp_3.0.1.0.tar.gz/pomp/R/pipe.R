##' @name pipe
##' @rdname pipe
##' @docType import
##' @keywords internal
##' @importFrom magrittr %>%
##' 
##' @details See \code{magrittr::\link[magrittr]{\%>\%}} for details.
##' 
##' @export
magrittr::`%>%`
