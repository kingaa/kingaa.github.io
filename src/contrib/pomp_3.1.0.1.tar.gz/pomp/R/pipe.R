##' @name pipe
##' @rdname pipe
##' @docType import
##' @keywords internal
##' @importFrom magrittr %>%
##' 
##' @details See \code{\link[magrittr::pipe]{magrittr::\%>\%}} for details.
##' 
##' @export
magrittr::`%>%`
