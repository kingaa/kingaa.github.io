##' Deprecated functions.
##'
##' These functions are obsolete and will be removed in a future release.
##'
##' @name deprecated
##' @rdname deprecated
##'
##' @author Aaron A. King
##'
##' @keywords internal
##' @param ...
##' In \code{profileDesign}, additional arguments specify the parameters over which to profile and the values of these parameters.
##' In \code{sliceDesign}, additional numeric vector arguments specify the locations of points along the slices.
##' 
NULL
