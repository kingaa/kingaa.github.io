library(pomp)
set.seed(39596886L)
rgammawn(5,sigma=1,dt=0.1)
rgammawn(5,sigma=0.1,dt=0.1)
