// -*- C++ -*-

#ifndef _POMP_INTERNAL_H_
#define _POMP_INTERNAL_H_

#include <R.h>
#include <Rmath.h>
#include <Rdefines.h>

#include "pomp_defines.h"
#include "decls.h"
#include "backports.h"

#endif
