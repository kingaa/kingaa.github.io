get_covariate_names <- function (object) {
  rownames(object@table)
}


