library(testthat)
library(spatPomp)

test_check("spatPomp")
