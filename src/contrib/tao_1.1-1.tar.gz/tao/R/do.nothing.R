do.nothing <- function (...) {
  invisible(NULL)
}
