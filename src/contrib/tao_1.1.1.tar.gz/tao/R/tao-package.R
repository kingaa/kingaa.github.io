#' That which cannot be packaged.
#' 
#' The package that can be described is not the great Tao package.
#' 
#' Without opening your door, you can open your heart to the world.\cr
#' Without looking out your window, you can see the essence of the Tao.\cr
#' The more you know, the less you understand.\cr
#' The Master arrives without leaving, sees the light without looking, achieves without doing a thing.
#' 
#' @name tao-package
#' @docType package
#' @author Lao Tsu, Aaron A. King
#' @seealso \code{\link{do.nothing}}, \code{\link{do.nothing.else}}
#' @references Lao Tsu, Tao Te Ching.
#' @keywords programming
NULL

