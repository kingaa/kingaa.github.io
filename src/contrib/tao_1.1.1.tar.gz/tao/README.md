---------------------

# tao

The package that can be documented is not the eternal package  
The procedure that terminates is not the eternal procedure  
The undocumented is the origin of feature and bug  
The documentation is the mother of limitless confusion  
Thus, constantly without desire, one observes the runtime errors  
Constantly with desire, one observes the progress bar  
These two emerge together but differ in name  
Their unity is said to be a mystery  
Mystery of mysteries, the door to the next revision  

---------------------

Manual: [(HTML)](https://kingaa.github.io/manuals/tao/html/00Index.html) [(PDF)](https://kingaa.github.io/manuals/tao/tao.pdf)  
Install: `install.packages("tao",repos="https://kingaa.github.io")`  

---------------------

[![Project Status: Active – The project has reached a stable, usable state and is being actively developed.](https://www.repostatus.org/badges/latest/active.svg)](https://www.repostatus.org/#active)
[![Development Release](https://img.shields.io/github/release/kingaa/tao.svg)](https://github.com/kingaa/tao/)
[![R-CMD-check](https://github.com/kingaa/tao/actions/workflows/r-cmd-check.yml/badge.svg)](https://github.com/kingaa/tao/actions/workflows/r-cmd-check.yml)
[![binary-build](https://github.com/kingaa/tao/actions/workflows/binary-build.yml/badge.svg)](https://github.com/kingaa/tao/actions/workflows/binary-build.yml)
[![test-coverage](https://github.com/kingaa/tao/actions/workflows/test-coverage.yml/badge.svg)](https://github.com/kingaa/tao/actions/workflows/test-coverage.yml)
[![codecov](https://codecov.io/gh/kingaa/tao/branch/master/graph/badge.svg?token=NrKxrA2CHS)](https://codecov.io/gh/kingaa/tao)
