Non-changes in 'tao' version 1.1.1:

- To know and yet think we do not know is the highest attainment; not to know and yet think we do know is a disease.
- It is simply by being pained at the thought of having this disease that we are preserved from it.
- The sage has not the disease. He knows the pain that would be inseparable from it, and therefore he does not have it.
