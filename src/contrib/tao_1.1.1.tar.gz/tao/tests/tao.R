library(tao)

do.nothing()
